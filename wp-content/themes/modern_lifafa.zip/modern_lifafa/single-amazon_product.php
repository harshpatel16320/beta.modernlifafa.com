<?php
if (!defined('ABSPATH'))
    exit;

get_header('shop');
?>

<?php

// Get the current post/product
global $product;


$gift_for = isset($_GET['gift_for']) ? intval($_GET['gift_for']) : 0;
$gift_for_user_id = isset($_GET['gift_for']) ? intval($_GET['gift_for']) : 0;
$user_exists = $gift_for_user_id ? get_user_by('ID', $gift_for_user_id) : false;
$logged_in = is_user_logged_in();
$user_id = $logged_in ? get_current_user_id() : '';
$disable_class = ($gift_for && !$logged_in) ? ['disabled'] : ['qty'];
if (function_exists('wc_print_notices')) {
    wc_print_notices();
}
?>

<section class="our-products-section">
    <div class="container">
        <?php if ($logged_in): ?>
            <a href="<?php echo home_url('/wishlist'); ?>" class="personalised-page" title="Go to Personalised Page">Go to
                Wishlist</a>
        <?php endif; ?>
    </div>
</section>

<?php while (have_posts()):
    the_post(); ?>
    <section class="product-detail-section">
        <div class="container">
            <div class="product-detail-wrap">

                <!-- Product Image -->
                <div class="product-img">
                    <div class="all-rated-img-cls-adding">
                        <picture class="product-image-cls-adding-all">
                            <?php
                            if (has_post_thumbnail()) {
                                the_post_thumbnail('large', ['class' => 'featured-image product-feature-img-cls-adding']);
                            } else {
                                echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/placeholder.png') . '" alt="No Image">';
                            }
                            ?>
                        </picture>
                    </div>
                </div>

                <!-- Product Details -->
                <div class="product-details">
                    <h3 class="product-title"><?php the_title(); ?></h3>

                    <!-- Product Price -->
                    <?php
                    $price = get_field('price');
					$is_out_of_stock = ($price <= 0);
                    if ($price) {
                        // Clean and convert the price to a proper numeric value
                        $price = str_replace(',', '', $price); // remove commas
                        $price = preg_replace('/[^\d.]/', '', $price); // remove any non-numeric characters except dot
                        $price = (float) $price; // convert to float
						// Check stock status
						$is_out_of_stock = ($price <= 0);
                        echo '<div class="price">₹' . number_format($price, 0, '.', ',') . '</div>';
                    }

                    ?>
                    <?php
                    $last_refresh = get_the_modified_time('F j, Y, g:i a'); // Example: October 17, 2025, 2:30 pm
                    ?>
                    <p class="spacing-cum-cls-added"> Amazon.in Price as of <span
                            class="last-refresh"><?php echo esc_html($last_refresh); ?></span>
                    </p>
                    <p class="spacing-cum-cls-added">Price and availability are subject to change</p>
                    <hr class="line">

                    <!-- Product Description Tabs -->
                    <div class="product-content">
                        <div class="tab-listing-cls-all-tabbing">
                            <div class="product-tabs">
                                <ul class="tab-nav">
                                    <li class="tab-link active" data-tab="product-description">Product Description</li>
                                </ul>
                                <div id="product-description"
                                    class="tab-content active newproduct-description-cls-adding-common product-description-content">
                                    <?php the_content(); ?>
                                </div>
                                <button class="see-more-btn" style="display:none;">See More</button>
                                <div class="spacing-additional-top-cls-here">
                                    <p class="spacing-cum-cls-added new-color-cls-adding-here">This product is sold and
                                        fulfilled by Amazon.<br> As an Amazon Associate, Modern Lifafa earns from qualifying
                                        purchases.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Add to Wishlist Button -->
                    <div class="add-product cash-product-gift new-add-product-gift-card-cls">
                        <?php $amazon_url = get_field('product_link'); ?>
                        <?php
                        $purchased = false;
                        $original_user_id = isset($_GET['original_user_id']) ? intval($_GET['original_user_id']) : 0;

                        if (is_user_logged_in() && !$purchased && (!$original_user_id)): ?>
                            <!-- <button class="custom_button add-to-personalized" type="button">Add to Wishlist</button> -->

                            <button type="button" class="custom_button primary_button_outline add-to-amazon-personalized <?php echo $is_out_of_stock ? 'disable_product_no_stock' : ''; ?>"
                                data-product-id="<?php echo get_the_ID(); ?>" data-amazon-url="<?php echo $amazon_url; ?>"
                                data-product-type="" data-action="add">
                                ADD TO REGISTRY</button>
                        <?php endif; ?>


                        <?php if ($amazon_url): ?>
                            <a data-details-amazon-url="<?php echo esc_url($amazon_url); ?>" target="_blank"
                                class="custom_button details-buy-amazon">
                                VIEW ON AMAZON
                            </a>
                        <?php endif;
                        ?>
                    </div>

                </div>

            </div>
        </div>
    </section>

<?php endwhile; ?>

<?php get_footer('shop'); ?>