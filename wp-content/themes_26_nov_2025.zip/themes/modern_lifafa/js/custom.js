jQuery(document).ready(function ($) {
    // alert('hello');
    // jQuery('.user_search').on('input', function () {
    $(document).on('input', '.user_search', function(e) {
       // alert('hello');
        var query = $(this).val().trim();
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'user_search',
                query: query,
            },
            success: function (response) {
                $('.search-results-list').html(response);
            }
        });
    });

    $('.model-close-btn').on('click', function () {
        $('.user_search').val('').trigger('input');
    });
});

jQuery(document).ready(function($) {
    $('.find-couple-popup').on('click', function(e) {
        e.preventDefault();
        elementorProFrontend.modules.popup.showPopup({id: 1989});
    });

    $(document).on('click', '#find-couple-cart', function(e) {
   // $('#find-couple-cart').on('click', function(e) {
        e.preventDefault();
        elementorProFrontend.modules.popup.showPopup({id: 1989});
    });

    // document.addEventListener('wpcf7mailsent', function(event) {
    //     elementorProFrontend.modules.popup.showPopup({id: 7212});
    // }, false);

});

jQuery(document).ready(function($) {
    $('.banner-images-popup').on('click', function(e) {
        e.preventDefault();
        elementorProFrontend.modules.popup.showPopup({id: 4718});
    });

    jQuery.ajax({
        url: ajaxurl,
        type: 'POST',
        data: {
            action: 'shipping_address_filled',
            // query: query,
        },
        success: function (response) {
            if (response.success) {
                // elementorProFrontend.modules.popup.showPopup({id: 2382});
            } else {
                $('.share-wishlist').addClass('disabled');
            }
        }
    });
});


jQuery(document).ready(function($) {
    $('.share-wishlist').on('click', function(e) {
        e.preventDefault();
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'shipping_address_filled',
                // query: query,
            },
            success: function (response) {
                if (response.success) {
                    elementorProFrontend.modules.popup.showPopup({id: 2382});
                } else {
                    $('.share-wishlist').addClass('disabled');
                }
            }
        });
    });
});
jQuery(document).ready(function($) {
    $('.delete_account').on('click', function(e) {
        // alert('hello');
        e.preventDefault();
        elementorProFrontend.modules.popup.showPopup({id: 3630});
    });

    // $(document).on('click', '#cancel-delete-btn', function(e) {
    //     e.preventDefault();
    //     elementorProFrontend.modules.popup.closePopup({id: 3630});
    // });
});

document.getElementById('copyButton').addEventListener('click', function() {
    var copyText = document.querySelector('.page_link_share');
    copyText.select();
    document.execCommand("copy");
    // alert("Copied: " + copyText.value);
});

/* Registration validation js start */

jQuery.validator.addMethod("customname", function(value, element) {
    return this.optional(element) || /^[a-zA-Z\s]+$/.test(value.trim());
}, "Please enter a valid name");
jQuery.validator.addMethod("customphone", function(value, element) {
    return this.optional(element) || /^\+?\d{10,14}$/.test(value);
}, "Please enter a valid phone number");
jQuery.validator.addMethod("strongPassword", function(value, element) {
    return this.optional(element) || /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/.test(value);
}, "Password must be at least 8 characters long and contain at least one number, one lowercase and one uppercase letter.");
jQuery.validator.addMethod("imageType", function(value, element) {
    return this.optional(element) || /\.(jpe?g|png|webp)$/i.test(value);
}, "Please upload a valid image (JPEG, JPG, PNG, WEBP).");
jQuery.validator.addMethod("futureDate", function(value, element) {
    var selectedDate = new Date(value);
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    return this.optional(element) || selectedDate >= today;
}, "Please select a future date as Wedding date.");
jQuery('#woocommerce-form-register').validate({
    rules: {
        billing_first_name: {
            required: true,
            customname: true,
            minlength: 2
        },
        billing_last_name: {
            required: true,
            customname: true,
            minlength: 2
        },
        email: {
            required: true,
            email: true,
        },
        // phone: {
        //     customphone: true,
        // },
        password_1: {
            required: true,
            strongPassword : true,
        },
        password_2: {
            equalTo: "#password_1",
        },
        partner_fname: {
            required: true,
            customname: true,
            minlength: 2
        },
        partner_lname: {
            required: true,
            customname: true,
            minlength: 2
        },
        wedding_date : {
            futureDate: true
        }
    },
    messages: {
        billing_first_name:{
            required:  "Please Enter Your First Name.",
            customphone:  "Please Enter valid Name",
            minlength : "Please Enter valid Name",
        },
        billing_last_name: {
            required:  "Please Enter Your Last Name.",
            customphone:  "Please Enter Valid Name",
            minlength : "Please Enter valid Name",
        },
        email: {
            required: "Please Enter Your Email.",
            email: "Please Enter Valid Email",
        },
        // phone:{
        //     customphone: "Please Enter Valid Phone Number",
        // },
        password_1: {
            required:  "Please Enter Your Password.",
            strongPassword: "Must be 8+ chars with a number, lowercase and uppercase."
        },
        password_2: {
            equalTo: "New Password and Confirm Password are not same.",
        },
        partner_fname: {
            required: "Please Enter Your Partner's First Name.",
            // customphone:  "Please Enter valid Name",
            minlength : "Please Enter valid Name",
        },
        partner_lname: {
            required: "Please Enter Your Partner's Last Name.",
            // customphone:  "Please Enter valid Name",
            minlength : "Please Enter valid Name",
        },
        wedding_date : {
            futureDate: "Please select a future date as Wedding date."
        }
    },
    errorElement: "div",
    errorPlacement: function(error, element) {
        element.after(error);
    }
});
/* Registration validation js End */

// Header search
jQuery(document).ready(function ($) {
    jQuery('.header_main_search').on('input', function(e) {
        e.preventDefault();
        var searchQuery = $('#s').val();
        $.ajax({
            url: ajaxurl,
            type: 'post',
            data: {
                action: 'search_results',
                search: searchQuery
            },
            success: function(response) {
                $('.load-search-result').html(response);
            }
        });
    });
});

/* Header search js Start */
jQuery(document).ready(function ($) {
    $(".search-open").click(function () {
        $(".search-box-wrapper").slideToggle();
    });

    $(".close-search-bar").click(function () {
        $('.header_main_search').text('');
        $('.header_main_search').val('');
        $('.load-search-result').html('');
        $(".search-box-wrapper").slideUp();
    });

    // Hide search-box-wrapper slideUp clicking outside
    $(document).click(function (e) {
        if (!$(e.target).closest(".search-open, .search-box-wrapper").length) {
        $(".search-box-wrapper").slideUp();
        }
    });
});
/* Header search js End */

jQuery(document).ready(function ($) {
    $(window).scroll(function () {
      if ($(this).scrollTop() > 50) { 
        $("header").addClass("scrolled");
      } else {
        $("header").removeClass("scrolled");
      }
    });

    jQuery('.password_hide_show').on('click', function() {
        var input = jQuery('#' + jQuery(this).data('id'));
        var showIcon = jQuery('#show_icon').val();
        var hideIcon = jQuery('#hide_icon').val();

        if (input.attr('type') === 'password') {
            input.attr('type', 'text');
            jQuery(this).find('img').attr('src', showIcon);
        } else {
            input.attr('type', 'password');
            jQuery(this).find('img').attr('src', hideIcon);
        }
    });

    $(document).on('click', '.add-to-personalized', function(e) {
        // alert('hello');
        e.preventDefault();
        var product_id = $(this).data('product-id');
        var button_action = $(this).data('action');
        var count = $('.product_count').text();
        var qty = $('.qty').val();
        var product_type = $(this).data('product-type');
        var variation_id = $('input[name="variation_id"]').val();
        // console.log(variation_id);
        var missingAttrs = [];
        $('.variations select').each(function () {
            if (!$(this).val()) {
                var label = $(this).closest('tr').find('label').text().trim().replace(':', '');
                missingAttrs.push(label);
            }
        });
        if (missingAttrs.length > 0 && $('.variations select').length >= 2) {
            toastr.error('Please select: ' + missingAttrs.join(', '));
            return;
        }
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'add_to_personalized',
                product_id: product_id,
                click_action : button_action,
                quantity : qty,
                variation_id : variation_id,
            },
            success: function(response) {
                if (button_action == 'remove' && response.success) {
                    $('#box'+product_id).remove();
                    count = count-1;
                    toastr.warning('Product Removed from your wishlist.');
                    // alert('Product Removed from your wishlist.');
                    $('.product_count').text(count);
                }else{
                    toastr.success(response.data.message);
                }
            }
        });

        $('#share-wishlist-modal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var link = button.attr('data-href');
            var encodedUrl = encodeURIComponent(link);
            var modal = $(this);
            modal.find('.page_link_share').val(link);
            $('.wtsp_share').attr('href', 'https://api.whatsapp.com/send?text='+encodedUrl);
            $('.fcbk_share').attr('href', 'https://www.facebook.com/sharer.php?u='+encodedUrl);
            $('.twtr_share').attr('href', 'https://twitter.com/intent/tweet?url='+encodedUrl+'&text=Personalised Page');
            $('.gmail_share').attr('href', 'mailto:?subject='+encodedUrl+'&body=Check%20this%20out:%20'+encodedUrl);
        });
    });
    
    // $(document).on('change', '#sort-options', function() {
    //     var sortValue = $(this).val();
    //     var user_id = $('.user_id').val();
    //     var received_gift = $('.received_gift').val();
    //     $.ajax({
    //         url: ajaxurl,
    //         type: 'POST',
    //         data: {
    //             action: 'sort_wishlist',
    //             sort_order: sortValue,
    //             user_id:user_id,
    //             received_gift:received_gift,
    //         },
    //         success: function(response) {
    //             $('.product-boxes').html(response);
    //         },
    //         error: function(xhr, status, error) {
    //             console.error('AJAX Error:', error);
    //         }
    //     });
    // });

    // $('#copyButton').click(function() {
    $(document).on('click', '#copyButton', function(e) {
        var copyText = $('.page_link_share');
        copyText.select();
        copyText[0].setSelectionRange(0, 99999);
        document.execCommand('copy');
        // $('.copied_msgs').html('Copied');
    });

  });


jQuery(document).ready($ => {
    // Toggle scroll-hide on popup show/hide
    jQuery(document).on('elementor/popup/show elementor/popup/hide', (e) => {
        jQuery('body').toggleClass('scroll-hide', e.type === 'elementor/popup/show');
    });
	jQuery('.elementor-menu-cart__toggle_button, .search--icon, .close-search-bar, .elementor-menu-cart__close-button,.header-nav .elementor-menu-toggle').on('click', () => {
        jQuery('body').toggleClass('scroll-hide');
    });
	
	// Remove scroll-hide when clicking anywhere outside the menu/cart
    jQuery(document).on('click', (e) => {
        if (!$(e.target).closest('.header-nav .elementor-menu-toggle, .elementor-menu-cart__toggle_button, .elementor-menu-cart__close-button').length) {
            jQuery('body').removeClass('scroll-hide');
        }
    });
    jQuery(document).on('click', '.elementor-menu-cart__toggle', () => {
        jQuery('body').addClass('scroll-hide');
    });
    
});

// smooth scrolling
jQuery(document).ready($ => {
    jQuery(".custom_button.secondary_button").click(function() {
        var banner = jQuery("#banner-section");

        if (banner.length) {  // ✅ Run only if #banner-section exists
            jQuery('html, body').animate({
                scrollTop: banner.offset().top - 150
            }, 800);
        }
    });
});



// jQuery(document).ready(function($) {
//     var logoutUrl = '<?php echo wp_logout_url( home_url() ); ?>';
//     $('.logout_site a').attr('href', logoutUrl);
// });

jQuery(document).ready(function($) {
    if (typeof myData !== 'undefined') {
        $('.logout_site a').attr('href', myData.logoutUrl);
    }
    // jQuery(document).on('#confirm-delete-btn', function(e) {
    jQuery(document).on('click', '#confirm-delete-btn', function(e) {
        const password = $('#account-password').val();
        if (!password) {
            alert('Please enter your password.');
            return;
        }
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'delete_account',
                password: password,
            },
            success: function(response) {
                if (response.success) {
                    alert('Your account has been deleted.');
                    window.location.href = myData.logoutUrl;
                } else {
                    alert(response.data.message);
                }
            }
        });
    });
    
$('#cancel-delete-btn').click(function() {
    $('.close-modal').trigger('click');
});
});
jQuery(document).ready(function ($) {
    $("#load-more").on("click", function () {
        let button = $(this);
        let offset = parseInt(button.data("offset"));
        let user_id = button.data("user");

        $.ajax({
            type: "POST",
            url: ajaxurl,
            data: {
                action: "load_more_wishlist_products",
                offset: offset,
                user_id: user_id
            },
            beforeSend: function () {
                button.text("Loading...");
            },
            success: function (response) {
                if (response.success) {
                    $("#product-list").append(response.data.html);
                    button.data("offset", response.data.new_offset);
                    button.text("Load More");

                    // Hide button if no more products
                    if (response.data.html.trim() === "") {
                        button.hide();
                    }
                } else {
                    button.text("No more products");
                }
            },
            error: function () {
                button.text("Error! Try again.");
            }
        });
    });


    // $(document).on('change', '.product-filter', function(e) {
    $(document).on('change', '.product-filter_cat, .product-filter', function(e) {
    // $('.product-filter').change(function () {
       // alert('hello');
        var category = $('.filter-category').find(":selected").val();
        var price = $('.filter-price').find(":selected").val();
        var brand = $('.filter-brand').find(":selected").val();
        
        var url = new URL(window.location.href);
        var params = new URLSearchParams(url.search);
    
        if(category) {
            params.set('category', category);
        } else {
            params.delete('category');
        }   
    
        if(price) {
            params.set('price', price);
        }else{
            params.delete('price');
        }
    
        if(brand) {
            params.set('filter_brand', brand);
        }else {
            params.delete('filter_brand');
        }
    
        var baseUrl = url.origin + url.pathname.split("page/")[0];
        var queryString = params.toString();
        var newUrl = baseUrl + (queryString ? '?' + queryString : '');
        window.location.href = newUrl.toString();
    });
});

var swiper = new Swiper(".popular-product-slider", {
    slidesPerView: 4,
    spaceBetween: 16,
    navigation: {
        nextEl: ".product-next",
        prevEl: ".product-prev",
    },
    breakpoints: {
        1281: {
            slidesPerView: 4,
        },
        1025: {
            slidesPerView: 3.5,
        },
        992: {
            slidesPerView: 3,
        },
        768:{
            slidesPerView: 3,
        },
        576:{
            slidesPerView: 2,
        },
        481:{
            slidesPerView: 1,
        },
        376:{
            slidesPerView: 1,
        },
        0:{
            slidesPerView: 1,
        },
    },
});

//===============  Product Details slide Js Start  ========================================================//

var sliderThumbnail = new Swiper('.products-thumbnail', {
    slidesPerView: 4,
    spaceBetween: 10,
    freeMode: true,
    watchSlidesVisibility: true,
    watchSlidesProgress: true,

    pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },

    breakpoints: {
        // when window width is >= 768px
        320: {
            slidesPerView: 4,
            spaceBetween: 10
        },
        768: {
            slidesPerView: 3,
            spaceBetween: 5
        },
        1280: {
            slidesPerView: 4,
            spaceBetween: 10
        }
    }

});

var slider = new Swiper('.products-slider', {
    slidesPerView: 1,
    navigation: {
    nextEl: '.product-button-next',
    prevEl: '.product-button-prev',
    },
    thumbs: {
    swiper: sliderThumbnail
    }
});

jQuery(document).ready(function($) {
    $('.product-content table').each(function() {
        $(this).wrap('<div class="content-table-section"></div>');
    });

    //$(".clear_filter").on("click", function() {
        jQuery(document).on('click', '.clear_filter', function (e) {
            e.preventDefault(); // Prevent default behavior
            $('#custom-preloader').show();
            var url = new URL(window.location.href);
            var baseUrl = url.origin + url.pathname.split("page/")[0];
            var coupleName = url.searchParams.get("couple_name");
            var originalUserId = url.searchParams.get("original_user_id");
            var queryParams = [];
            if (coupleName) {
                queryParams.push('couple_name=' + encodeURIComponent(coupleName));
            }
            if (originalUserId) {
                queryParams.push('original_user_id=' + encodeURIComponent(originalUserId));
            }
            if (queryParams.length > 0) {
                baseUrl += '?' + queryParams.join('&');
            }
            window.location.href = baseUrl;
        });
        
});


// Banner image js

// jQuery(document).ready(function ($) {
//     $('.upload-banner-image').click(function (e) {
//             e.preventDefault();
//             var button = $(this);
//             var inputField = button.prev('input');
//             var imgPreview = button.next('img');
            
//                 var mediaUploader = wp.media({
//                 title: 'Choose Image',
//                 library: { type: 'image' },
//                 button: { text: 'Select' },
//                 multiple: false
//                 }).on('select', function () {
//             var attachment = mediaUploader.state().get('selection').first().toJSON();
//             inputField.val(attachment.url);
//             imgPreview.attr('src', attachment.url).show();
//             }).open();
//         });
//     });

jQuery(document).ready(function ($) {
    $(document).on('change', '.filter-dropdown', function() {
    let selectedCategory = $('#category-filter').val();
    let selectedBrand = $('#brand-filter').val();
    
    let baseUrl = window.location.pathname; // Get clean URL
    let params = new URLSearchParams(window.location.search);

    // Remove filter when it's "All" to prevent unnecessary URL parameters
    if (selectedCategory && selectedCategory !== 'All') {
        params.set('category', selectedCategory);
    } else {
        params.delete('category');
    }

    if (selectedBrand && selectedBrand !== 'All') {
        params.set('brand', selectedBrand);
    } else {
        params.delete('brand');
    }

    // Construct final URL
    let newUrl = baseUrl + '?' + params.toString();
    window.location.href = newUrl;
});


    $('.clear_filter').click(function () {
        window.location.href = window.location.pathname; // Reset filters
    });
    
    $('.reset_variations').click(function () {
        window.location.href = window.location.pathname; // Reset filters
    });
});


// Accept reject received gift

jQuery(document).ready(function ($) {
    const EXPIRY_TIME = 24 * 60 * 60 * 1000; 

    function checkGiftExpiry() {
        $('.received-box').each(function () {
            const giftBox = $(this);
            const orderId = giftBox.data('order-id');
            const itemId = giftBox.data('item-id');
            const orderTimeRaw = giftBox.data('order-time');
            const orderTime = parseInt(orderTimeRaw, 10) * 1000 || 0;
            let currentStatus = giftBox.data('status'); 

            // console.log(`Checking Order ID: ${orderId}, Item ID: ${itemId}`);
            // console.log(`Raw Order Time: ${orderTimeRaw}`);
            // console.log(`Parsed Order Time: ${orderTime}`);
            // console.log(`Current Status: ${currentStatus}`);

            // Ensure valid order time
            if (!orderTime || isNaN(orderTime)) {
                // console.warn(`Invalid order time for order ${orderId}, item ${itemId}`);
                return;
            }

            // If already accepted or rejected, do NOT expire
            if (currentStatus === 'accepted' || currentStatus === 'rejected') {
                return;
            }

            const timeElapsed = Date.now() - orderTime;
            // console.log(`Time Elapsed: ${timeElapsed}ms`);

            // Expire only if the gift has no status set (pending) and time exceeds limit
            if (!currentStatus || currentStatus === 'pending') {
                if (timeElapsed > EXPIRY_TIME) {
                    updateGiftStatus(itemId, orderId, 'expired', giftBox);
                }
            }
        });
    }

    // Run expiry check every 1 seconds
    setInterval(checkGiftExpiry, 60 * 60 * 1000);

    $('.accept-gift').on('click', function () {
        const button = $(this);
        const action = button.data('action');
        const giftBox = button.closest('.received-box');
        const itemId = giftBox.data('item-id');
        const orderId = giftBox.data('order-id');
        $('#custom-preloader').show();
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'handle_gift_status',
                item_id: itemId,
                order_id: orderId,
                status: action
            },
            success: function (response) {
                $('#custom-preloader').hide();
                if (response.success) {
                    giftBox.data('status', action);
                    giftBox.find('.accept-gift, .reject-gift').remove();
                    // giftBox.append(`<button type="button" class="custom_button secondary_button" disabled>${response.data.message}</button>`);
                    giftBox.find('.received-actions').html(
                        `<button type="button" class="custom_button secondary_button" disabled>${response.data.message}</button>`
                    );
                } else {
                    alert('Error: ' + response.data.message);
                }
            }
        });
    });

    // Function to update gift status when expired
    function updateGiftStatus(itemId, orderId, status, giftBox) {
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'handle_gift_status',
                item_id: itemId,
                order_id: orderId,
                status: status
            },
            success: function (response) {
                if (response.success) {
                    // Update status locally
                    giftBox.data('status', 'expired');

                    // Ensure "Expired" button is only shown if it was pending before
                    giftBox.find('.accept-gift, .reject-gift').remove();
                    giftBox.append('<button type="button" class="custom_button secondary_button" disabled>Expired</button>');

                    // console.log(`Gift Expired for Order ID: ${orderId}, Item ID: ${itemId}`);
                } else {
                    alert('Error: ' + response.data.message);
                }
            }
        });
    }
});

jQuery(document).ready(function($) {
    let homeUrl = window.location.origin; // Get home URL dynamically
    $("style").each(function() {
        $(this).html($(this).html().replace(/{{HOME_URL}}/g, homeUrl));
    });
});


// Wishlist custom profile image auto upload code
jQuery(document).ready(function ($) {
    $('#profile_picture_input').on('change', function (e) {
        e.preventDefault();
        $('#custom-preloader').show();
        let fileInput = this;
        if (!fileInput.files || !fileInput.files[0]) {
            alert("Please select a valid image file.");
            $('#custom-preloader').css('display', 'none');
            return;
        }
        let formData = new FormData();
        formData.append('action', 'update_user_profile_picture');
      //  formData.append('security', ajax_object.nonce);
        formData.append('profile_picture', fileInput.files[0]); 
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function () {
                //$('#update_message').text('Uploading...').show();
            },
            success: function (response) {
                if (response.success) {
                    let newImageUrl = response.data.image_url + "?t=" + new Date().getTime(); 
                    $('.user_profile').attr('src', newImageUrl);
                    setTimeout(function () {
                        location.reload();
                    }, 500);
                } else {
                    alert('Error: ' + (response.data.message || 'Unexpected error.'));
                }
            },
            error: function (xhr, status, error) {
                console.log("AJAX Error:", xhr.responseText);
                alert('An error occurred while uploading. Check console for details.');
            }
        });
        $('#custom-preloader').css('display', 'none');
    });

    // $('form.cart').on('click', '.icon-minus-circle, .icon-plus-circle', function() {
    //     var $qty = $('.qty');
    //     var currentVal = parseFloat($qty.val());
    //     // alert(currentVal);
    //     var max = parseFloat($qty.attr('max'));
    //     var min = parseFloat($qty.attr('min'));
    //     var step = parseFloat($qty.attr('step'));
    //     if ($(this).is('.icon-plus-circle')) {
    //         if (max && (max <= currentVal)) {
    //             $qty.val(max);
    //         } else {
    //             $qty.val(currentVal + step);
    //         }
    //     } else {
    //         if (min && (min >= currentVal)) {
    //             $qty.val(min);
    //         } else if (currentVal > 1) {
    //             $qty.val(currentVal - step);
    //         }
    //     }
    //     $qty.trigger('change');
    // });
});

// Quantity Add

(function () {
    const quantityContainer = document.querySelector(".quantity");
    const minusBtn = quantityContainer.querySelector(".minus");
    const plusBtn = quantityContainer.querySelector(".plus");
    const inputBox = quantityContainer.querySelector(".input-box");
  
    updateButtonStates();
  
    quantityContainer.addEventListener("click", handleButtonClick);
    inputBox.addEventListener("input", handleQuantityChange);
  
    function updateButtonStates() {
      const value = parseInt(inputBox.value);
      minusBtn.disabled = value <= 1;
      plusBtn.disabled = value >= parseInt(inputBox.max);
    }
  
    function handleButtonClick(event) {
      if (event.target.classList.contains("minus")) {
        decreaseValue();
      } else if (event.target.classList.contains("plus")) {
        increaseValue();
      }
    }
  
    function decreaseValue() {
      let value = parseInt(inputBox.value);
      value = isNaN(value) ? 1 : Math.max(value - 1, 1);
      inputBox.value = value;
      updateButtonStates();
      handleQuantityChange();
    }
  
    function increaseValue() {
      let value = parseInt(inputBox.value);
      value = isNaN(value) ? 1 : Math.min(value + 1, parseInt(inputBox.max));
      inputBox.value = value;
      updateButtonStates();
      handleQuantityChange();
    }
  
    function handleQuantityChange() {
      let value = parseInt(inputBox.value);
      value = isNaN(value) ? 1 : value;
  
      // Execute your code here based on the updated quantity value
      console.log("Quantity changed:", value);
    }
});

jQuery(function ($) {
    function applyCheckboxLogic() {
        var $checkbox = $('#contact-namespace-toggle-shipping-address');
        if ($checkbox.length) {
            console.log('Checkbox found, applying logic.');

            if (!$checkbox.is(':checked')) {
                console.log('Checkbox is not checked on load. Forcing check.');
                $checkbox.prop('checked', true); 
            } else {
                console.log('Checkbox is already checked on load.');
            }

            $checkbox.off('change').on('change', function () {
                console.log('Checkbox state changed. Is checked?', $(this).is(':checked'));
                if ($(this).is(':checked')) {
                    console.log('Checkbox is checked.');
                    $('.wp-block-woocommerce-checkout-shipping-address-block').hide();
                } else {
                    console.log('Checkbox is unchecked.');
                    $('.wp-block-woocommerce-checkout-shipping-address-block').show();
                }
            });
        } else {
            // console.log('Checkbox not found.');
        }
    }

    setTimeout(function () {
        // console.log('Retrying after delay.');
        applyCheckboxLogic();
    }, 1000);

    jQuery(document).on('input', '#custom-price', function(e) {
        this.value = this.value.replace(/[^0-9]/g, '');
    });

    jQuery(document).on('click', '#custom-price', function(e) {
        $(this).removeClass('disable_selection');
        // $(this).prop("disabled", false)
        $('#lifafa').addClass('disable_selection');
        // $("#lifafa").attr("disabled", "disabled");
        this.value = this.value.replace(/[^0-9]/g, ''); 
    });

    // $("#custom-price").on("click", function () {
    // jQuery(document).on('click', '#custom-price', function(e) {
    //     $("#attribute-lifafa").attr("disabled", "disabled");
    // });

    // $("#lifafa").on("click", function () {
    jQuery(document).on('click', '#lifafa', function(e) {
        $(this).removeClass('disable_selection');
        // $(this).prop("disabled", false)
        // $("#custom-price").attr("disabled", "disabled");
        $('#custom-price').addClass('disable_selection');
    });
    // $('.woocommerce-shipping-fields').css('display', 'none');
    setTimeout(() => {
        // $('#ship-to-different-address-checkbox').prop("checked", true).trigger("change"); 
        // $('#ship-to-different-address').css('display', 'none');
        $('.shipping_address').css('display','none');
    }, 210);
});

jQuery(document).ready(function($) {
    // Enable "Place Order" button immediately
    $('#place_order').prop('disabled', false);

    // Hide WooCommerce loader (spinner)
    $(document).on('ajaxStart', function() {
        $('.blockUI, .woocommerce-checkout-review-order .blockUI').hide(); 
    });

    // Ensure "Place Order" remains enabled after AJAX calls
    $(document).on('ajaxStop', function() {
        $('#place_order').prop('disabled', false);
    });
});

jQuery(document).on('elementor/popup/show', function() {
    jQuery('body').addClass('open-modal');
});

// Remove class when popup is closed
jQuery(document).on('elementor/popup/hide', function() {
    jQuery('body').removeClass('open-modal');
});

// Received gift after accept code bank details check 
document.addEventListener("DOMContentLoaded", function () {
    var ok_button = 0;
    document.querySelectorAll(".accept-gift-transfer").forEach(function (button) {
        button.addEventListener("click", function (event) {
            let hasBankDetails = this.getAttribute("data-user-has-bank") === "true";

            if (!hasBankDetails) {
                event.preventDefault();
                ok_button = 1;
                showNotification("<div class='share-wishlist-address transfer_cash_received'><strong>Almost there!</strong><br>We just need a few more details to transfer your funds.<br><br>You can securely provide your bank information <a href='"+myData.homeUrlJs+"my-account' class='save_address_link'>here</a>.</div>");
            }else{
                const button = jQuery(this);
                const action = button.data('action');
                const giftBox = button.closest('.received-box');
                const itemId = giftBox.data('item-id');
                const orderId = giftBox.data('order-id');
                jQuery('#custom-preloader').show();
                jQuery.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'handle_gift_status',
                        item_id: itemId,
                        order_id: orderId,
                        status: action
                    },
                    success: function (response) {
                        jQuery('#custom-preloader').hide();
                        if (response.success) {
                            giftBox.data('status', action);
                            giftBox.find('.accept-gift, .reject-gift').remove();
                            // giftBox.append(`<button type="button" class="custom_button secondary_button" disabled>${response.data.message}</button>`);
                            giftBox.find('.received-actions').html(
                                `<button type="button" class="custom_button secondary_button" disabled>${response.data.message}</button>`
                            );
                        } else {
                            alert('Error: ' + response.data.message);
                        }
                    }
                });
            }
        });
    });

    jQuery(document).on('click', '.share-wishlist.disabled', function(e) {
        ok_button = 1;
		showNotification("<div class='share-wishlist-address'><strong>Almost there!</strong><br>Please add your shipping address before sharing your registry link—so your gifts can arrive right at your doorstep!<br><br>You can update your address <a href='"+myData.homeUrlJs+"my-account' class='save_address_link'>here</a></div>");
	});

    // Show notification message

    function showNotification(message, callback) {
        let notification = document.createElement("div");
        notification.className = "custom-notification";
        // if(ok_button == 1){
        //      notification.innerHTML = `
        //     <div class="notification-content">
        //         <div class="message"><p>${message}</p></div>
        //         <button class="notification-btn">OK</button>
        //     </div>`;
        // }else{
            notification.innerHTML = `
            <div class="notification-content">
                <div class="message"><p>${message}</p></div>
                <button class="notification-btn">OK</button>
            </div>`;
        // }
        document.body.appendChild(notification);
        document.body.classList.add("open-modal");

        jQuery(document).on("click",".notification-btn", function ($) {
            jQuery("body").removeClass("open-modal");
            jQuery(".notification").remove(); 
            jQuery(".custom-notification").hide(); // Close the pop up
            if (typeof callback === "function") {
                callback();
            }
        });
    }
    
});

// function showNotificationWithTwoButton(message, onConfirm, onCancel) { 
//     let notification = document.createElement("div");
//     notification.className = "custom-notification";
//     notification.innerHTML = `
//         <div class="notification-content">
//            ${message}
//             <div class="notification-buttons">
//                 <button class="notification-btn confirm-btn">Yes I’m sure</button>
//                 <button class="notification-btn cancel-btn">Go Back</button>
//             </div>
//         </div>
//     `;

//     document.body.appendChild(notification);
//     document.body.classList.add("open-modal");

//     document.querySelector(".confirm-btn").addEventListener("click", function () {
//         document.body.removeChild(notification);
//         document.body.classList.remove("open-modal");
//         if (onConfirm) onConfirm();
//     });

//     document.querySelector(".cancel-btn").addEventListener("click", function () {
//         document.body.removeChild(notification);
//         document.body.classList.remove("open-modal");
//         if (onCancel) onCancel();
//     });
// }

// same as billing

function showNotificationWithTwoButton(message, onConfirm, onCancel) { 
    let notification = document.createElement("div");
    notification.className = "custom-notification";
    notification.innerHTML = `
        <div class="notification-content">
            <p>${message}</p>
            <div class="notification-buttons">
                <button class="notification-btn confirm-btn">Yes I’m sure</button>
                <button class="notification-btn cancel-btn">Go Back</button>
            </div>
        </div>
    `;

    document.body.appendChild(notification);
    document.body.classList.add("open-modal");

    document.querySelector(".confirm-btn").addEventListener("click", function () {
        document.body.removeChild(notification);
        document.body.classList.remove("open-modal");
        if (onConfirm) onConfirm();
    });

    document.querySelector(".cancel-btn").addEventListener("click", function () {
        document.body.removeChild(notification);
        document.body.classList.remove("open-modal");
        if (onCancel) onCancel();
    });
}
 
 
window.addEventListener("load", function() {
    const sameAsBillingCheckbox = document.querySelector("input[name='same_as_billing']");
    if (sameAsBillingCheckbox && sameAsBillingCheckbox.checked) {
        autoFillShippingDetails();
    }
});
document.addEventListener('DOMContentLoaded', function () {
    const sameAsBillingCheckbox = document.querySelector("input[name='same_as_billing']");
    if (sameAsBillingCheckbox) {
        sameAsBillingCheckbox.addEventListener('change', function () {
            if (sameAsBillingCheckbox.checked) {
                autofillShippingAddress();
            } else {
    
                clearShippingAddress();
            }
        });
    }
 
    function autofillShippingAddress() {
        const billingFirstName = document.querySelector("input[name='billing_first_name']").value;
        const billingLastName = document.querySelector("input[name='billing_last_name']").value;
        const billingAddress1 = document.querySelector("input[name='billing_address_1']").value;
        const billingAddress2 = document.querySelector("input[name='billing_address_2']").value;
        const billingCity = document.querySelector("input[name='billing_city']").value;
        const billingPostcode = document.querySelector("input[name='billing_postcode']").value;
        const billingState = document.querySelector("select[name='billing_state']").value;
 
        document.querySelector("input[name='shipping_first_name']").value = billingFirstName;
        document.querySelector("input[name='shipping_last_name']").value = billingLastName;
        document.querySelector("input[name='shipping_address_1']").value = billingAddress1;
        document.querySelector("input[name='shipping_address_2']").value = billingAddress2;
        document.querySelector("input[name='shipping_city']").value = billingCity;
        document.querySelector("input[name='shipping_postcode']").value = billingPostcode;
        document.querySelector("select[name='shipping_state']").value = billingState;
    }
 
    function clearShippingAddress() {
        document.querySelector("input[name='shipping_first_name']").value = '';
        document.querySelector("input[name='shipping_last_name']").value = '';
        document.querySelector("input[name='shipping_address_1']").value = '';
        document.querySelector("input[name='shipping_address_2']").value = '';
        document.querySelector("input[name='shipping_city']").value = '';
        document.querySelector("input[name='shipping_postcode']").value = '';
        document.querySelector("select[name='shipping_state']").value = '';
 
        console.log("Shipping details cleared.");
    }
});

jQuery(document).ready(function($) {
    $('#deliver_to_couple_hidden').val(1);
   // Make sure this is only run once
    $('#deliver_to_couple_hidden').on('change', function () {
        $(this).val(this.checked ? '1' : '0');
    });

    $('#custom-checkout-form').on('submit', function(e) {
        e.preventDefault(); // Always prevent by default
        let error = false;

        // Reset preloader on every submit attempt
        $('#custom-preloader').hide();

        const requiredFields = [
            { id: '#billing_first_name', message: 'Billing first name is required.' },
            { id: '#billing_last_name', message: 'Billing last name is required.' },
            { id: '#billing_email', message: 'Billing email is required.' },
            { id: '#billing_address_1', message: 'Billing address is required.' },
            { id: '#billing_city', message: 'Billing city is required.' },
            { id: '#billing_postcode', message: 'Billing postcode is required.' },
            { id: '#billing_country', message: 'Billing country is required.' },
            { id: '#shipping_address_1', message: 'Shipping address is required.' },
            { id: '#shipping_city', message: 'Shipping city is required.' },
            { id: '#shipping_postcode', message: 'Shipping postcode is required.' },
            // { id: '#shipping_country', message: 'Shipping country is required.' }
        ];

        requiredFields.forEach(function(field) {
            const input = $(field.id);
            if (input.length && !input.val().trim()) {
                error = true;
                toastr.warning(field.message);
            }
        });

        if (!$('#terms').is(':checked')) {
            error = true;
            toastr.warning("You must accept the terms and conditions.");
        }

        if (!error) {
            $('#custom-preloader').show();
            this.submit(); // Only trigger native form submission if no error
        }
    });

});

// jQuery(document).ready(function($) {
//     $('#custom-checkout-form').submit(function(e) {
//         e.preventDefault();
//         if (!$("#custom-checkout-form").valid()) {
//             return;
//         } else {
//             $('#custom-preloader').show();
//             $.ajax({
//                 type: 'POST',
//                 url: ajaxurl,
//                 data: $(this).serialize() + '&action=process_custom_checkout',
//                 success: function(response) {
//                     if (response.success) {
//                         window.location.href = response.data.redirect;
//                     } else {
//                         alert(response.data.message || 'Error processing checkout.');
//                         window.location.href = '/checkout/order-received/';
//                     }
//                 },
//                 error: function() {
//                     alert('An unexpected error occurred.');
//                     window.location.href = '/checkout/order-received/';
//                 }
//             });
//         }
//     });
// });



// jQuery(document).ready(function($) {
//     $('#custom-checkout-form').submit(function(e) {
//         e.preventDefault();

//         $.ajax({
//             type: 'POST',
//             url: wc_checkout_params.ajax_url,
//             data: $(this).serialize() + '&action=process_checkout',
//             dataType: 'json',
//             beforeSend: function() {
//                 $('#checkout-response').html('<p>Processing...</p>');
//             },
//             success: function(response) {
//                 if (response.success) {
//                     window.location.href = response.redirect;
//                 } else {
//                     $('#checkout-response').html('<p style="color: red;">' + response.error + '</p>');
//                 }
//             }
//         });
//     });
// });


// Search functionality in my account page in address (1)

// jQuery(document).ready(function($) {
//     var autocompleteService = new google.maps.places.AutocompleteService();
//     var inputField = $('#address-input');
//     var suggestionsList = $('#address-suggestions');
//     inputField.on('input', function () {
//         var query = $(this).val();
//         if (!query) {
//             suggestionsList.empty().hide();
//             return;
//         }
//         // Fetch autocomplete suggestions
//         autocompleteService.getPlacePredictions({ input: query }, function (predictions, status) {
//             if (status === google.maps.places.PlacesServiceStatus.OK) {
//                 suggestionsList.empty().show();
//                 predictions.forEach(function (prediction) {
//                     suggestionsList.append('<li style="padding: 5px; cursor: pointer;" data-place-id="' + prediction.place_id + '">' + prediction.description + '</li>');
//                 });
//             }
//         });
//     });

//     // Handle suggestion click
//     suggestionsList.on('click', 'li', function () {
//         var selectedAddress = $(this).text();
//         inputField.val(selectedAddress);
//         suggestionsList.empty().hide();
//         var data = {
//             action: 'save_selected_address',
//             address: selectedAddress
//         };

//         $.post(ajax_obj.ajaxurl, data, function (response) {
//             console.log('Address saved successfully:', response);
//         });
//     });
// });

jQuery(document).ready(function ($) {
    jQuery('.remove_product').on('click', function () {
        var product_id = $(this).data('product_id');
        let productBox = $(this).closest('.presonalised-item');

        showNotificationWithTwoButton1(
            "Are you sure you want to remove this item?",
            function () {
                // User clicked OK - Proceed with removal
                $('#custom-preloader').show();
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        product_id1: product_id,
                        action: 'remove_from_personalized',
                    },
                    success: function (response) {
                        $('#custom-preloader').hide();
                        if (response.success) {
                            toastr.success('Product removed from your Wishlist.');
                            productBox.fadeOut(300, function () {
                                $(this).remove();
                            });
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function () {
                        toastr.warning('Something went wrong. Please try again.');
                    }
                });
            },
            function () {
                // User clicked Cancel - Just close popup
                console.log("Product removal canceled.");
            }
        );
    });

    // Custom notification popup function
    function showNotificationWithTwoButton1(message, onConfirm, onCancel) { 
        let notification = document.createElement("div");
        notification.className = "custom-notification";
        notification.innerHTML = `
            <div class="notification-content">
                <p>${message}</p>
                <div class="notification-buttons">
                    <button class="notification-btn confirm-btn">Remove</button>
                    <button class="notification-btn cancel-btn">Cancel</button>
                </div>
            </div>
        `;

        document.body.appendChild(notification);
        document.body.classList.add("open-modal");

        document.querySelector(".confirm-btn").addEventListener("click", function () {
            document.body.removeChild(notification);
            document.body.classList.remove("open-modal");
            if (onConfirm) onConfirm(); // Execute confirm function
        });

        document.querySelector(".cancel-btn").addEventListener("click", function () {
            document.body.removeChild(notification);
            document.body.classList.remove("open-modal");
            if (onCancel) onCancel(); // Execute cancel function
        });
    }
});


// jQuery(document).ready(function ($) {
//     $('.remove_product').on('click', function () {
//         var product_id = $(this).data('product_id');
//         let productBox = $(this).closest('.presonalised-item');
//         $('#custom-preloader').show();
//         $.ajax({
//             url: ajaxurl,
//             type: 'POST',
//             data: {
//                 product_id1: product_id,
//                 action: 'remove_from_personalized',
//             },
//             beforeSend: function () {
//                 console.log('Removing product...');
//             },
//             success: function (response) {
//                 $('#custom-preloader').hide();
//                 if (response.success) {
//                     toastr.success('Product removed from your Wishlist.');
//                     productBox.fadeOut(300, function () {
//                         $(this).remove();
//                     });
//                 } else {
//                     alert(response.message);
//                 }
//             },
//             error: function () {
//                 toastr.warning('Something went wrong. Please try again.');
//             }
//         });
//     });
// });


// jQuery(document).ready(function ($) {
//     $('#category-filter').change(function () {
//         let category = $(this).val();
//         let user_id = $('.user_id').val(); 

//         $.ajax({
//             url: ajaxurl,
//             type: "POST",
//             data: {
//                 action: "filter_wishlist_by_category",
//                 user_id: user_id,
//                 category: category
//             },
//             beforeSend: function () {
//                 $('#wishlist-products').html('<p>Loading...</p>'); // Show loading text
//             },
//             success: function (response) {
//                 $('#wishlist-products').html(response); // Update wishlist
//             }
//         });
//     });
// });

jQuery(document).ready(function ($) {
    function fetchFilteredAndSortedProducts() {
        var sortValue = $('#sort-options').val();
        var selectedCategory = $('#category-filter').val(); // Assuming a category dropdown exists
        var user_id = $('.user_id').val();
        var received_gift = $('.received_gift').val();
        var urlParams = new URLSearchParams(window.location.search);
        var gift_for = urlParams.get('original_user_id');
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'filter_and_sort_wishlist',
                sort_order: sortValue,
                category: selectedCategory, // Pass category in AJAX
                user_id: user_id,
                received_gift: received_gift,
                gift_for: gift_for
            },
            success: function (response) {
                $('.product-boxes').html(response);
                $('#custom-preloader').hide();
            }
        });
    }
    const currentPage = window.location.pathname;
    if (localStorage.getItem('filter-page') !== currentPage) {
        localStorage.removeItem('category-filter');
        localStorage.removeItem('sort-options');
        localStorage.setItem('filter-page', currentPage);
    }
    if (localStorage.getItem('category-filter')) {
        $('#category-filter').val(localStorage.getItem('category-filter'));
    }

    if (localStorage.getItem('sort-options')) {
        $('#sort-options').val(localStorage.getItem('sort-options'));
    }
    if (localStorage.getItem('category-filter') || localStorage.getItem('sort-options')) {
        fetchFilteredAndSortedProducts();
    }
    $(document).on('change', '#category-filter', function () {
        $('#custom-preloader').show();
        var selectedCategory = $(this).val();
        localStorage.setItem('category-filter', selectedCategory);
        localStorage.setItem('filter-page', currentPage);
        fetchFilteredAndSortedProducts();
    });
    $(document).on('change', '#sort-options', function () {
        $('#custom-preloader').show();
        var sortValue = $(this).val();
        localStorage.setItem('sort-options', sortValue);
        localStorage.setItem('filter-page', currentPage);
        fetchFilteredAndSortedProducts();
    });
    $(document).on('click', '.clear_filter', function () {
        $('#category-filter').val('');
        $('#sort-options').val('');
        localStorage.removeItem('category-filter');
        localStorage.removeItem('sort-options');
        fetchFilteredAndSortedProducts();
    });

   const observer = new MutationObserver(() => {
    const selectors = document.querySelectorAll('.wc-block-components-quantity-selector');

    selectors.forEach(selector => {
        const minus = selector.querySelector('.wc-block-components-quantity-selector__button--minus');
        const plus = selector.querySelector('.wc-block-components-quantity-selector__button--plus');
        const qty_input = selector.querySelector('.wc-block-components-quantity-selector__input');

        if (minus && plus && qty_input) {
            minus.setAttribute('disabled', true);
            plus.setAttribute('disabled', true);
            qty_input.setAttribute('disabled', true);
        }
    });

    // Optionally disconnect if you're sure all elements are loaded
    if (selectors.length > 0) {
        observer.disconnect();
    }
});

// Start observing the entire document or a specific container
observer.observe(document.body, {
    childList: true,
    subtree: true
});

    
    observer.observe(document.body, { childList: true, subtree: true });
    
});

// jQuery(document).ready(function ($) {
    
// });


jQuery(document).on('input', '.custom_amount', function($) {
    if (parseFloat(jQuery(this).val()) < 1) {
        jQuery(this).val(1);
    }
})

// add to cart
jQuery(document).ready(function($) {
    jQuery(document).on('click', '.add_to_cart_from_wishlist', function(e) {
        $(this).attr('disabled', 'disabled');
        e.preventDefault();
        var unique_key = $(this).data('key');
        var custom_amount = $('.custom_amount_'+ unique_key).val();
        // alert(custom_amount);
        if($(this).hasClass('is_cash_product') && custom_amount == ''){
            toastr.warning('Please Enter Amount Of Lifafa.');
            return false;
        }
        $('#custom-preloader').show();
        var product_id = $(this).val();
        var attributes = $('#hidden_attributes_' + unique_key).val();
        var quantity = $('#hidden_quantity_' + unique_key).val();
        var gift_for = new URLSearchParams(window.location.search).get('original_user_id');
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'add_to_cart_with_variations',
                product_id: product_id,
                attributes: attributes,
                quantity: quantity,
                gift_for: gift_for,
                custom_amount:custom_amount
            },
            success: function(response) {
                if (response.success) {
                    toastr.success('Product Added to Cart.');
                    location.reload();
                } else {
                   toastr.warning(response.data.message);
                }
            }
        });
    });
});

jQuery(document).ready(function ($) {
    $(document).on('submit', '.wpcf7-form', function () {
        $('#custom-preloader').show();
    });

    document.addEventListener('wpcf7mailsent', function () {
        $('#custom-preloader').hide();
    });

    document.addEventListener('wpcf7invalid', function () {
        $('#custom-preloader').hide();
    });

    document.addEventListener('wpcf7spam', function () {
        $('#custom-preloader').hide();
    });

    document.addEventListener('wpcf7failed', function () {
        $('#custom-preloader').hide();
    });
});


jQuery(document).on('click', '.icon-minus-circle, .icon-plus-circle', function($) {
    var $qty = jQuery('.qty');
    var currentVal = parseFloat($qty.val());
    // alert(currentVal);
    var max = parseFloat($qty.attr('max'));
    var min = parseFloat($qty.attr('min'));
    var step = parseFloat($qty.attr('step'));
    if (jQuery(this).is('.icon-plus-circle')) {
        if (max && (max <= currentVal)) {
            $qty.val(max);
        } else {
            $qty.val(currentVal + step);
        }
    } else {
        if (min && (min >= currentVal)) {
            $qty.val(min);
        } else if (currentVal > 1) {
            $qty.val(currentVal - step);
        }
    }
    $qty.trigger('change');
});

jQuery(function($) {
	// When a variation is selected
	$('form.variations_form').on('show_variation', function(event, variation) {
		if (variation.image && variation.image.full_src) {
			// Replace main image
			const newImage = variation.image.full_src;
			$('.products-slider .swiper-slide.variation-main-slide img').attr('src', newImage);

			// Optional: Replace thumbnail too (if needed)
			$('.products-thumbnail .swiper-slide.variation-thumb-slide img').attr('src', newImage);
		}
	});
});

jQuery(document).ready(function($) {

    $('.elementor-menu-cart__close-button').on('click', function(){
        setTimeout(() => {
            $('body').removeClass('scroll-hide').css('overflow', '');
        }, 500);
    });

    $('body').on('click', '.qty-plus', function() {
        var $input = $(this).siblings('.personalized-product-qty');
        var currentVal = parseInt($input.val()) || 1;
        $input.val(currentVal + 1).trigger('change');
    });

    $('body').on('click', '.qty-minus', function() {
        var $input = $(this).siblings('.personalized-product-qty');
        var currentVal = parseInt($input.val()) || 1;
        if (currentVal > 1) {
            $input.val(currentVal - 1).trigger('change');
        }
    });

    // AJAX update when quantity changes
    // $('body').on('change', '.personalized-product-qty', function() {
    //     var $input = $(this);
    //     var product_id = $input.data('product_id');
    //     var variation_id = $input.data('variation_id');
    //     var qty = $input.val();
    //     var attributes = $input.data('attributes'); // JSON object

    //     var data = {
    //         action: 'update_personalized_product_quantity',
    //         product_id: product_id,
    //         variation_id: variation_id,
    //         qty: qty,
    //         attributes: attributes,
    //         // security: personalized_product_nonce.security
    //     };

    //     $.ajax({
    //         url: ajaxurl,
    //         method: 'POST',
    //         data: data,
    //         success: function(response) {
    //             if (response.success) {
    //                 console.log(response.data.message);
    //             } else {
    //                 console.error(response.data.message);
    //             }
    //         },
    //         error: function() {
    //             console.error('AJAX error');
    //         }
    //     });
    // });


    // $('body').on('click', '.update_wishlist_qty', function () {
    //     var $btn = $(this);
    //     var $input = $btn.closest('.wishlist-item').find('.personalized-product-qty');
    
    //     var product_id = $input.data('product_id');
    //     var variation_id = $input.data('variation_id');
    //     var qty = $input.val();
    //     var attributes = $input.data('attributes'); // JSON object
    
    //     var data = {
    //         action: 'update_personalized_product_quantity',
    //         product_id: product_id,
    //         variation_id: variation_id,
    //         qty: qty,
    //         attributes: attributes
    //     };
    
    //     $.ajax({
    //         url: ajaxurl,
    //         method: 'POST',
    //         data: data,
    //         success: function(response) {
    //             if (response.success) {
    //                 console.log(response.data.message);
    //             } else {
    //                 console.error(response.data.message);
    //             }
    //         },
    //         error: function() {
    //             console.error('AJAX error');
    //         }
    //     });
    // });

    $('body').on('click', '.update_wishlist_qty', function () {
    var $btn = $(this);
    var qty_attr = $(this).attr('id');
    var $input = $btn.closest('.product-quantity').find('.personalized-product-qty');

    var product_id = $input.data('product_id');
    var variation_id = $input.data('variation_id');
    var qty = $input.val();
    var attributes = $input.data('attributes'); // likely a JS object

    var data = {
        action: 'update_personalized_product_quantity',
        product_id: product_id,
        variation_id: variation_id,
        qty: qty,
        attributes: JSON.stringify(attributes) // important!
    };
    $.ajax({
        url: ajaxurl,
        type: 'POST',
        data: data,
        success: function (response) {
            if (response.success) {
                console.log(qty_attr);
                $('.'+qty_attr).text(qty);
                console.log(response.data.message);
            } else {
                console.error(response.data.message);
            }
        },
        error: function () {
            console.error('AJAX error');
        }
    });
});

    
});

document.addEventListener('DOMContentLoaded', function() {
   
    const tabs = document.querySelectorAll('.tab-link');
    const contents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', function() {

            tabs.forEach(tab => tab.classList.remove('active'));
            contents.forEach(content => content.classList.remove('active'));

            this.classList.add('active');
            const target = document.getElementById(this.getAttribute('data-tab'));
            target.classList.add('active');

            console.log("Active tab:", this.getAttribute('data-tab'));
        });
    });
});

// document.addEventListener('wpcf7mailsent', function(event) {
//     $('#cf7-success-popup').fadeIn();

//     // Auto-hide after 5 seconds
//     setTimeout(function() {
//         $('#cf7-success-popup').fadeOut();
//     }, 5000);
// }, false);


// document.addEventListener('DOMContentLoaded', function () {
//     document.addEventListener('wpcf7mailsent', function (event) {
//         console.log("riddhi");
//         document.getElementById('cf7-success-popup').style.display = 'flex';
//     }, false);

//     document.addEventListener('DOMContentLoaded', function () {
//         const closeBtn = document.getElementById('popup-close');
//         if (closeBtn) {
//             closeBtn.addEventListener('click', function () {
//                 document.getElementById('cf7-success-popup').style.display = 'none';
//             });
//         }
//     });
// });


// document.addEventListener("DOMContentLoaded", function () {
// 	const limitFields = ['gift_message', 'order_comments'];

// 	// Enforce live character trimming while typing
// 	limitFields.forEach(id => {
// 		const textarea = document.getElementById(id);
// 		if (textarea) {
// 			textarea.addEventListener('input', function () {
// 				if (this.value.length > 150) {
// 					this.value = this.value.substring(0, 150);
// 					alert("Maximum 150 characters allowed.");
// 				}
// 			});
// 		}
// 	});

// 	// Prevent form submission if any field exceeds 150 chars
// 	const form = document.getElementById('custom-checkout-form');
// 	if (form) {
// 		form.addEventListener('submit', function (e) {
// 			let isValid = true;

// 			limitFields.forEach(id => {
// 				const field = document.getElementById(id);
// 				if (field && field.value.length > 150) {
// 					alert(`The "${id.replace('_', ' ')}" field cannot exceed 150 characters.`);
// 					isValid = false;
// 				}
// 			});

// 			if (!isValid) {
// 				e.preventDefault(); // Stop the form from submitting
// 			}
// 		});
// 	}
// });

function toggleRupeeSymbol(input) {
  const rupeeSymbol = input.parentElement.querySelector('.rupee-symbol');
  if (input.value.trim() !== '') {
    rupeeSymbol.style.opacity = 1;
  } else {
    rupeeSymbol.style.opacity = 0;
  }
}

