<?php
/**
 * modern_lifafa Theme Customizer
 *
 * @package modern_lifafa
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function modern_lifafa_customize_register($wp_customize)
{
    $wp_customize->get_setting('blogname')->transport = 'postMessage';
    $wp_customize->get_setting('blogdescription')->transport = 'postMessage';
    $wp_customize->get_setting('header_textcolor')->transport = 'postMessage';

    if (isset($wp_customize->selective_refresh)) {
        $wp_customize->selective_refresh->add_partial(
            'blogname',
            array(
                'selector' => '.site-title a',
                'render_callback' => 'modern_lifafa_customize_partial_blogname',
            )
        );
        $wp_customize->selective_refresh->add_partial(
            'blogdescription',
            array(
                'selector' => '.site-description',
                'render_callback' => 'modern_lifafa_customize_partial_blogdescription',
            )
        );
    }
}
add_action('customize_register', 'modern_lifafa_customize_register');

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function modern_lifafa_customize_partial_blogname()
{
    bloginfo('name');
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function modern_lifafa_customize_partial_blogdescription()
{
    bloginfo('description');
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function modern_lifafa_customize_preview_js()
{
    wp_enqueue_script('modern_lifafa-customizer', get_template_directory_uri() . '/js/customizer.js', array('customize-preview'), _S_VERSION, true);
}
add_action('customize_preview_init', 'modern_lifafa_customize_preview_js');


// Fetch Orders for Given User
function get_orders_by_user($user_id)
{
    $meta_key = '_gift_for';
    $user_orders = [];

    $args = [
        'limit' => -1,
        'status' => ['completed', 'processing'],
        'return' => 'ids',
    ];
    $orders = wc_get_orders($args);

    if (!empty($orders)) {
        foreach ($orders as $order_id) {
            $order = wc_get_order($order_id);
            if ($order) {
                foreach ($order->get_items() as $item) {
                    if ($item->get_meta($meta_key, true) == $user_id) {
                        $user_orders[] = $order_id;
                        break;
                    }
                }
            }
        }
    }
    return $user_orders;
}

add_action('wp_head', 'myplugin_ajaxurl');
function myplugin_ajaxurl()
{
    echo '<script type="text/javascript">
   var ajaxurl = "' . admin_url('admin-ajax.php') . '";
   </script>';
}

function ajax_search_results()
{
    $search_query = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    // if (!empty($search_query)) {
    $args = array(
        'posts_per_page' => 8,
        'post_type' => array('post', 'product', 'page'),
    );
    if (!empty($search_query)) {
        $args['s'] = $search_query;
    }
    $query = new WP_Query($args);
    $total_pages = $query->max_num_pages;
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()), 'thumbnail');
            $type = get_post_type();
            if ($type != 'faqs') {
                echo '<li><a href="' . get_permalink() . '">';
                if (isset($url) && !empty($url)) {
                    echo '<span class="result-img"><picture><img src="' . $url . '" alt="result image" width="30" height="30"></picture></span>';
                }
                echo '<span class="result-content">' . get_the_title() . '</span></a></li>';
            }
        }
    } else {
        echo '<span class="result-no-content">No results found.</span>';
    }
    // if($total_pages > 1){
    //     echo "<div class='search_view_more'><a href=''>View More</a></div>";
    // }
    wp_reset_postdata();
    // }
    wp_die();
}
add_action('wp_ajax_search_results', 'ajax_search_results');
add_action('wp_ajax_nopriv_search_results', 'ajax_search_results');

function morden_lifafa_pagination($links, $total_pages, $paged)
{
    echo '<ul class="pagination">';
    if ($paged > 1) {
        echo '<li class="page-item">';
        echo '<a class="page-link np-button" href="' . get_pagenum_link($paged - 1) . '" aria-label="Previous">';
        echo '<span aria-hidden="true" class="fas fa-chevron-left"></span>';
        echo '</a>';
        echo '</li>';
    } else {
        echo '<li class="page-item disabled">';
        echo '<a class="page-link np-button" href="javascript:void(0)" aria-label="Previous">';
        echo '<span aria-hidden="true" class="fas fa-chevron-left"></span>';
        echo '</a>';
        echo '</li>';
    }
    foreach ($links as $link) {
        if (strpos($link, 'current') !== false) {
            echo '<li class="page-item active">' . str_replace('page-numbers', 'page-link', $link) . '</li>';
        } else {
            echo '<li class="page-item">' . str_replace('page-numbers', 'page-link', $link) . '</li>';
        }
    }
    if ($paged < $total_pages) {
        echo '<li class="page-item">';
        echo '<a class="page-link np-button" href="' . get_pagenum_link($paged + 1) . '" aria-label="Next">';
        echo '<span aria-hidden="true" class="fas fa-chevron-right"></span>';
        echo '</a>';
        echo '</li>';
    } else {
        echo '<li class="page-item disabled">';
        echo '<a class="page-link np-button" href="javascript:void(0)" aria-label="Next">';
        echo '<span aria-hidden="true" class="fas fa-chevron-right"></span>';
        echo '</a>';
        echo '</li>';
    }
    echo '</ul>';
}

function add_dynamic_css_variable()
{
    $site_url = get_site_url(); // Get dynamic site URL
    echo "<style>:root { --site-hostname: url('$site_url'); }</style>";
}
add_action('wp_head', 'add_dynamic_css_variable');


// Footer preloader
function footer_preloader()
{
    if (!is_home() || !is_front_page()) { ?>
        <!-- Preloader Container -->
        <style>
            #custom-preloader {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.8);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 9999;
            }

            @keyframes rotateImage {
                0% {
                    transform: rotate(0deg);
                }

                100% {
                    transform: rotate(-360deg);
                }
            }

            .animated-image {
                width: 150px;
                height: 150px;
                object-fit: contain;
                animation: rotateImage 3s linear infinite;
            }
        </style>

        <div id="custom-preloader" style="display:none;">
            <img src="https://beta.modernlifafa.com/wp-content/uploads/2025/03/preloader.webp"
                alt="Rotating Image" class="animated-image" />
            <!-- 	<video width="100%" height="450" border="0" autoplay muted preload="auto">
                <source src="https://beta.modernlifafa.com/wp-content/uploads/2025/03/ML_LogoAnimationInverse.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video> -->
        </div>
    <?php }
}
add_action('wp_footer', 'footer_preloader');



function filter_and_sort_wishlist() {
    $sort_order = isset($_POST['sort_order']) ? sanitize_text_field($_POST['sort_order']) : '';
    $selected_category = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : ''; 
    $user_id = isset($_POST['user_id']) ? sanitize_text_field($_POST['user_id']) : get_current_user_id();
    $received_gift = isset($_POST['received_gift']) ? sanitize_text_field($_POST['received_gift']) : [];
    if (!empty($received_gift)) {
        $received_gift = explode(',', $received_gift);
    }
    // Get all personalized product data
    $wishlist_items = get_user_meta($user_id, '_personalized_products', true);
    $product_qty = get_user_meta($user_id, '_product_quantity', true);
    // Filter by Category
    if (!empty($selected_category) && is_array($wishlist_items)) {
        $wishlist_items = array_filter($wishlist_items, function ($item) use ($selected_category) {
            $product_id = $item['product_id'];
            $product_categories = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'ids'));
            return in_array($selected_category, $product_categories);
        });
    }
    // Sort by Price
    // if (!empty($wishlist_items) && is_array($wishlist_items)) {
    //     foreach ($wishlist_items as $key => &$product_data) {
    //         $product_id = $product_data['product_id'];
    //         $saved_attributes = $product_data['attributes'] ?? [];
    //         $product = wc_get_product($product_id);
    //         if (!$product) continue;
    //         $display_price = 0;
    //         if ($product->is_type('variable')) {
    //             $available_variations = $product->get_available_variations();
    //             foreach ($available_variations as $variation) {
    //                 $match = true;
    //                 foreach ($saved_attributes as $attribute_name => $attribute_value) {
    //                     if ($variation['attributes'][$attribute_name] !== $attribute_value) {
    //                         $match = false;
    //                         break;
    //                     }
    //                 }
    //                 if ($match) {
    //                     $variation_product = wc_get_product($variation['variation_id']);
    //                     if ($variation_product) {
    //                        $variation_product = wc_get_product($variation['variation_id']);
    //                         $display_price = $variation_product ? (float) $variation_product->get_price() : 0;
    //                     }
    //                 } else {
    //                     $display_price = (float) $product->get_price();
    //                 }
    //             }
            
    //         }
    //         $product_data['display_price'] = $display_price;
    //     }
    //     unset($product_data);
    //     $sort_order = $sort_order ?? 'price-asc';
    //     usort($wishlist_items, function ($a, $b) use ($sort_order) {
    //         $price_a = $a['display_price'] ?? 0;
    //         $price_b = $b['display_price'] ?? 0;
    //         return ($sort_order === 'price-asc') ? ($price_a <=> $price_b) : ($price_b <=> $price_a);
    //     });
    // }
    if (!empty($wishlist_items) && is_array($wishlist_items)) {
        foreach ($wishlist_items as $key => &$product_data) {
            $product_id = $product_data['product_id'];
            $saved_attributes = $product_data['attributes'] ?? [];
            $product = wc_get_product($product_id);
            if (!$product) continue;

            $display_price = 0;

            if ($product->is_type('variable')) {
                $available_variations = $product->get_available_variations();
                foreach ($available_variations as $variation) {
                    $match = true;
                    foreach ($saved_attributes as $attribute_name => $attribute_value) {
                        if (
                            !isset($variation['attributes'][$attribute_name]) ||
                            $variation['attributes'][$attribute_name] !== $attribute_value
                        ) {
                            $match = false;
                            break;
                        }
                    }
                    if ($match) {
                        $variation_product = wc_get_product($variation['variation_id']);
                        if ($variation_product) {
                            $display_price = (float) $variation_product->get_price();
                            break; // Stop once matched
                        }
                    }
                }
                // If no match found, fallback to parent product price
                if ($display_price === 0) {
                    $display_price = (float) $product->get_price();
                }
            } else {
                // Simple product
                $display_price = (float) $product->get_price();
            }

            $product_data['display_price'] = $display_price;
        }
        unset($product_data);

        // Set default sort order if not provided
        // $sort_order = $sort_order ?? 'price-asc';

        // Sort based on display_price
        usort($wishlist_items, function ($a, $b) use ($sort_order) {
            $price_a = $a['display_price'] ?? 0;
            $price_b = $b['display_price'] ?? 0;
            return ($sort_order === 'price-asc') ? ($price_a <=> $price_b) : ($price_b <=> $price_a);
        });
    }

    // Load Updated Wishlist
    $gift_for = isset($_POST['gift_for']) ? sanitize_text_field($_POST['gift_for']) : '';
    if ($wishlist_items) {
        // var_dump($wishlist_items);
        // exit();
        personalised_products($wishlist_items, $product_qty, $user_id, $received_gift, $gift_for);
    }
    
    wp_die();
}
add_action('wp_ajax_filter_and_sort_wishlist', 'filter_and_sort_wishlist');
add_action('wp_ajax_nopriv_filter_and_sort_wishlist', 'filter_and_sort_wishlist');

?>