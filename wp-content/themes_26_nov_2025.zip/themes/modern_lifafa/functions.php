<?php
/**
 * modern_lifafa functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package modern_lifafa
 */

if (!defined('_S_VERSION')) {
	// Replace the version number of the theme on each release.
	define('_S_VERSION', '1.0.0');
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function modern_lifafa_setup()
{
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on modern_lifafa, use a find and replace
	 * to change 'modern_lifafa' to the name of your theme in all the template files.
	 */
	load_theme_textdomain('modern_lifafa', get_template_directory() . '/languages');

	// Add default posts and comments RSS feed links to head.
	add_theme_support('automatic-feed-links');

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support('title-tag');

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support('post-thumbnails');

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__('Primary', 'modern_lifafa'),
		)
	);

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'modern_lifafa_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support('customize-selective-refresh-widgets');

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height' => 250,
			'width' => 250,
			'flex-width' => true,
			'flex-height' => true,
		)
	);
}
add_action('after_setup_theme', 'modern_lifafa_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function modern_lifafa_content_width()
{
	$GLOBALS['content_width'] = apply_filters('modern_lifafa_content_width', 640);
}
add_action('after_setup_theme', 'modern_lifafa_content_width', 0);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function modern_lifafa_widgets_init()
{
	register_sidebar(
		array(
			'name' => esc_html__('Sidebar', 'modern_lifafa'),
			'id' => 'sidebar-1',
			'description' => esc_html__('Add widgets here.', 'modern_lifafa'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget' => '</section>',
			'before_title' => '<h2 class="widget-title">',
			'after_title' => '</h2>',
		)
	);
}
add_action('widgets_init', 'modern_lifafa_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function modern_lifafa_scripts()
{
	wp_enqueue_style('modern_lifafa-style', get_stylesheet_uri(), array(), _S_VERSION);
	wp_style_add_data('modern_lifafa-style', 'rtl', 'replace');
	wp_enqueue_style('morden-lifafa-toaster', get_template_directory_uri() . '/assets/css/toastr.min.css', array(), _S_VERSION);
	wp_enqueue_style('morden-lifafa-swiper', get_template_directory_uri() . '/assets/css/swiper-bundle.min.css', array(), _S_VERSION);
	wp_enqueue_script('morden-lifafa-swiper-bundle', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', array(), _S_VERSION, true);
	wp_enqueue_script('morden-lifafa-form-validate', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js');
	wp_enqueue_script('modern_lifafa-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);
	wp_enqueue_script('morden-lifafa-toaster', get_template_directory_uri() . '/assets/js/toastr.min.js', array(), _S_VERSION, true);
	wp_enqueue_script('modern_lifafa-custom-js', get_template_directory_uri() . '/js/custom.js', array(), _S_VERSION, true);
	wp_localize_script('modern_lifafa-custom-js', 'myData', array(
		'logoutUrl' => wp_logout_url(home_url()),
		'homeUrlJs' => trailingslashit(home_url()) //  Ensures trailing slash
	));
	wp_enqueue_script('modern_lifafa-development-js', get_template_directory_uri() . '/js/development.js', array(), _S_VERSION, true);
	wp_enqueue_script('modern_lifafa-custom-validation-js', get_template_directory_uri() . '/js/custom_validation.js', array(), _S_VERSION, true);
	// wp_localize_script('modern_lifafa-custom-js', 'ajaxurl', admin_url('admin-ajax.php'));

	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}
}
add_action('wp_enqueue_scripts', 'modern_lifafa_scripts');

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

require get_template_directory() . '/inc/woocommerce.php';
require get_template_directory() . '/inc/development.php';

/**
 * Custom Payment.
 */
// require get_template_directory() . '/inc/custom-payment.php';

// require_once plugin_dir_path(__FILE__) . 'custom-elementor-blocks/wishlist-widget/wishlist-widget.php';

require get_template_directory() . '/inc/elementor_shortcodes.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require get_template_directory() . '/inc/jetpack.php';
}

function ajax_user_search()
{
	global $wpdb;
	$search_query = isset($_POST['query']) ? sanitize_text_field($_POST['query']) : '';
	$search_terms = array_filter(explode(' ', $search_query));

	$user_ids = [];
	$meta_conditions = [];

	if (!empty($search_terms)) {
		// Searching in core WP user fields (username, email, display name)
		foreach ($search_terms as $term) {
			$user_query = new WP_User_Query([
				'search' => $term, // Exact word match
				'search_columns' => ['user_login', 'user_nicename', 'user_email', 'display_name'],
				'role__not_in' => ['Administrator'],
				'fields' => 'ID',
			]);
			$user_ids = array_merge($user_ids, $user_query->get_results());
		}

		// Searching in user meta fields (first_name, last_name, partner_fname, partner_lname)
		foreach ($search_terms as $term) {
			// Ensuring exact word match (not partial)
			$meta_conditions[] = $wpdb->prepare(
				"(meta_key IN ('first_name', 'last_name', 'partner_fname', 'partner_lname') AND meta_value REGEXP %s)",
				'[[:<:]]' . $wpdb->esc_like($term) . '[[:>:]]'
			);
		}

		// Executing the meta query
		if (!empty($meta_conditions)) {
			$meta_query = "SELECT DISTINCT user_id FROM $wpdb->usermeta WHERE " . implode(' OR ', $meta_conditions);
			$meta_results = $wpdb->get_col($meta_query);
		} else {
			$meta_results = [];
		}

		// Merge all user IDs (from WP_Query & direct DB search)
		$all_user_ids = array_unique(array_merge($user_ids, $meta_results));

		if (!empty($all_user_ids)) {
			$args = [
				'include' => $all_user_ids,
				'number' => 8, // Limit results
			];
			$users = get_users($args);

			if (!empty($users)) {
				foreach ($users as $user) {
					$first_name = get_user_meta($user->ID, 'first_name', true);
					$last_name = get_user_meta($user->ID, 'last_name', true);
					$partner_fname = get_user_meta($user->ID, 'partner_fname', true);
					$partner_lname = get_user_meta($user->ID, 'partner_lname', true);
					$profile_picture = get_user_meta($user->ID, 'profile_picture', true);

					echo '<li>';
					echo '<a href="' . home_url() . '/wishlist/?couple_name=' . urlencode($first_name . '-and-' . $partner_fname) . '&original_user_id=' . $user->ID . '">';

					if ($profile_picture) {
						echo '<span><picture><img src="' . esc_url($profile_picture) . '" alt="couple image"></picture></span>';
					}

					echo '<strong>' . esc_html($first_name . ' ' . $last_name) . ' and ' . esc_html($partner_fname . ' ' . $partner_lname) . '</strong>';
					echo '</a>';
					echo '</li>';
				}
			} else {
				echo '<li>No users found.</li>';
			}
		} else {
			echo '<li>No users found.</li>';
		}
	} else {
		echo '<li>Please enter a search term.</li>';
	}

	wp_die();
}



add_action('wp_ajax_user_search', 'ajax_user_search');
add_action('wp_ajax_nopriv_user_search', 'ajax_user_search');

function custom_dynamic_bg()
{
	$user_id = isset($_GET['original_user_id']) ? $_GET['original_user_id'] : get_current_user_id();
	$backgroundImage = get_user_meta($user_id, 'selected_banner', true);
	if (empty($backgroundImage) || $backgroundImage == '') {
		$backgroundImage = get_field('default_banner', 'options');
	}
	$custom_css = "
        .dynamic-bg {
            background-image: url('$backgroundImage');
            background-repeat: no-repeat;
            background-size: cover;
        }
    ";
	wp_add_inline_style('modern_lifafa-style', $custom_css);
}
add_action('wp_enqueue_scripts', 'custom_dynamic_bg');

function add_custom_user_role()
{
	$customer_role = get_role('customer');
	$customer_capabilities = $customer_role->capabilities;
	add_role('registered_customer', 'Registered Customer', $customer_capabilities);
}
add_action('init', 'add_custom_user_role');

add_action('woocommerce_registration_errors', 'check_email_before_registration', 10, 3);
function check_email_before_registration($errors, $username, $email)
{
	if (email_exists($email)) {
		$errors->add('email_exists', __('This email is already registered. Please use another email.', 'woocommerce'));
	}
	return $errors;
}

add_action('user_register', 'save_custom_registration_fields');
function save_custom_registration_fields($customer_id)
{
	if (isset($_POST['billing_first_name'])) {
		update_user_meta($customer_id, 'first_name', sanitize_text_field($_POST['billing_first_name']));
	}
	if (isset($_POST['billing_last_name'])) {
		update_user_meta($customer_id, 'last_name', sanitize_text_field($_POST['billing_last_name']));
	}
	if (isset($_POST['phone'])) {
		update_user_meta($customer_id, 'phone', sanitize_text_field($_POST['phone']));
	}
	if (isset($_POST['email'])) {
		update_user_meta($customer_id, 'email', sanitize_email($_POST['email']));
	}
	if (isset($_POST['password_1'])) {
		wp_set_password($_POST['password_1'], $customer_id);
	}
	if (isset($_POST['partner_fname'])) {
		update_user_meta($customer_id, 'partner_fname', sanitize_text_field($_POST['partner_fname']));
	}
	if (isset($_POST['partner_lname'])) {
		update_user_meta($customer_id, 'partner_lname', sanitize_text_field($_POST['partner_lname']));
	}
	if (isset($_POST['secondary_email'])) {
		update_user_meta($customer_id, 'secondary_email', sanitize_email($_POST['secondary_email']));
	}
	if (isset($_POST['wedding_venue'])) {
		update_user_meta($customer_id, 'wedding_venue', sanitize_text_field($_POST['wedding_venue']));
	}
	if (isset($_POST['wedding_date'])) {
		update_user_meta($customer_id, 'wedding_date', sanitize_text_field($_POST['wedding_date']));
	}
	if (isset($_POST['our_story'])) {
		update_user_meta($customer_id, 'our_story', sanitize_text_field($_POST['our_story']));
	}

	if (isset($_FILES['profile_image'])) {
		if (!function_exists('wp_handle_upload')) {
			require_once(ABSPATH . 'wp-admin/includes/file.php');
		}
		$file = $_FILES['profile_image'];
		$upload_overrides = array('test_form' => false);
		$upload = wp_handle_upload($file, $upload_overrides);
		if (!isset($upload['error']) && isset($upload['url'])) {
			update_user_meta($customer_id, 'profile_picture', $upload['url']);
		}
	}

	$user = new WP_User($customer_id);
	if ($user->has_cap('customer_capability') && in_array('customer', $user->roles)) {
		$user->set_role('registered_customer');
	}
}


function user_not_loggedin()
{
	if (!is_user_logged_in() && is_page('wishlist') && !isset($_GET['couple_name'])) {
		wp_redirect(wc_get_page_permalink('myaccount'));
		exit;
	}
	if (!is_user_logged_in() && is_page('password-change')) {
		wp_redirect(wc_get_page_permalink('myaccount'));
		exit;
	}
	if (!is_user_logged_in() && is_page('received-gifts')) {
		wp_redirect(wc_get_page_permalink('myaccount'));
		exit;
	}
	if (is_user_logged_in() && is_page('my-account')) {
		$user = wp_get_current_user();
		if (in_array('seller', (array) $user->roles)) {
			wp_safe_redirect(home_url('/dashboard'));
			exit();
		}
	}
	if (is_user_logged_in() && is_page('wishlist')) {
		$user = wp_get_current_user();
		if (in_array('seller', (array) $user->roles)) {
			wp_safe_redirect(home_url('/dashboard'));
			exit();
		}
		// exit;
	}
}
add_action('template_redirect', 'user_not_loggedin');

function redirect_after_account_update($user_id)
{
	if (!is_admin()) {
		wp_redirect(site_url('/wishlist/'));
		exit;
	}
}
add_action('woocommerce_save_account_details', 'redirect_after_account_update', 20, 1);

function redirect_to_wishlist_after_login($user_login, $user)
{
	if (!is_admin() && isset($user->roles)) {
		if (in_array('seller', (array) $user->roles)) {
			wp_safe_redirect(site_url('/dashboard/'));
		} else {
			wp_safe_redirect(site_url('/wishlist/'));
		}
		exit;
	}
}
add_action('wp_login', 'redirect_to_wishlist_after_login', 10, 2);

add_action('wp_ajax_handle_gift_status', 'handle_gift_status');
add_action('wp_ajax_nopriv_handle_gift_status', 'handle_gift_status');

function handle_gift_status()
{
	$item_id = intval($_POST['item_id']);
	$order_id = intval($_POST['order_id']);
	$status = sanitize_text_field($_POST['status']);

	if (!$item_id || !$order_id) {
		wp_send_json_error(['message' => 'Invalid request.']);
	}

	$order = wc_get_order($order_id);
	if (!$order) {
		wp_send_json_error(['message' => 'Order not found.']);
	}

	$item = $order->get_item($item_id);
	if (!$item) {
		wp_send_json_error(['message' => 'Item not found.']);
	}
	$item->update_meta_data('_gift_status', 'confirm');
	// $item->update_meta_data('_gift_status', $status === 'transfer' ? 'transfered' : 'shipped');
	$item->save();

	wp_send_json_success(['message' => ucfirst($status) . 'ed']);
}

function custom_remove_dokan_dashboard_nav($urls)
{
	unset($urls['withdraw']);
	unset($urls['settings']);
	unset($urls['visit-store']);
	return $urls;
}
add_filter('dokan_get_dashboard_nav', 'custom_remove_dokan_dashboard_nav');

function load_more_wishlist_products()
{
	if (!isset($_POST['offset'], $_POST['user_id'])) {
		wp_send_json_error('Invalid Request');
		wp_die();
	}

	$offset = intval($_POST['offset']);
	$user_id = intval($_POST['user_id']);
	$limit = 9; // Load 9 more products

	$personalized_products = get_user_meta($user_id, '_personalized_products', true) ?? [];
	$received_item = [];

	$products_to_load = array_slice($personalized_products, $offset, $limit);
	$html = '';

	foreach ($products_to_load as $product_id) {
		$html .= (new Wishlist_Widget())->get_product_html($product_id, $user_id, $received_item);
	}

	wp_send_json_success(['html' => $html, 'new_offset' => $offset + $limit]);
	wp_die();
}
add_action('wp_ajax_load_more_wishlist_products', 'load_more_wishlist_products');
add_action('wp_ajax_nopriv_load_more_wishlist_products', 'load_more_wishlist_products');

// Add a custom field before the order notes in the checkout page
add_action('woocommerce_before_order_notes', 'add_custom_checkout_field');

function add_custom_checkout_field($checkout)
{
	echo '<div id="my_custom_checkout_field"><h2>' . __('Gift Message') . '</h2>';

	woocommerce_form_field('gift_message', array(
		'type' => 'textarea',
		'class' => array('my-field-class form-row-wide'),
		'label' => __('Enter your gift message'),
		'placeholder' => __('Enter your gift message here'),
	), $checkout->get_value('gift_message'));

	echo '</div>';
}
add_action('woocommerce_checkout_update_order_meta', 'save_gift_message_checkout_field');

function save_gift_message_checkout_field($order_id)
{
	if (!empty($_POST['gift_message'])) {
		update_post_meta($order_id, 'gift_message', sanitize_textarea_field($_POST['gift_message']));
	}
}


// Auto suggest

function search_location()
{
	if (isset($_POST['search'])) {
		$search = urlencode($_POST['search']);
		$url = "https://nominatim.openstreetmap.org/search?q=$search&format=json&addressdetails=1&limit=10";

		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_USERAGENT, 'modern-lifafa/1.0 (your-email@example.com)');

		$response = curl_exec($ch);
		curl_close($ch);

		$data = json_decode($response, true);
		$results = [];

		if (is_array($data) && count($data) > 0) {
			foreach ($data as $result) {
				$address = $result['address'];
				$results[] = [
					"display_name" => $result['display_name'] ?? '',
					"street" => $address['road'] ?? '',
					"city" => $address['city'] ?? ($address['town'] ?? ($address['village'] ?? '')),
					"state" => $address['state'] ?? '',
					"zipcode" => $address['postcode'] ?? '',
					"country" => $address['country'] ?? ''
				];
			}
		}

		// Return JSON response
		header('Content-Type: application/json');
		echo json_encode($results);
		exit();
	}
}
add_action('wp_ajax_search_location', 'search_location');
add_action('wp_ajax_nopriv_search_location', 'search_location'); // Allow non-logged-in users


add_filter('woocommerce_cart_item_price', 'update_cart_item_price', 10, 3);
function update_cart_item_price($price, $cart_item, $cart_item_key)
{
	if (isset($cart_item['variation_id']) && $cart_item['variation_id'] > 0) {
		$variation = new WC_Product_Variation($cart_item['variation_id']);

		$price = $variation->get_price_html();
	}
	return $price;
}
function get_variation_price()
{
	$product_id = intval($_POST['product_id']);
	$attributes = isset($_POST['attributes']) ? $_POST['attributes'] : array();

	if (!empty($attributes)) {
		$user_id = get_current_user_id();
		update_user_meta($user_id, '_product_attributes_' . $product_id, $attributes);
	}

	$product = wc_get_product($product_id);

	if ($product && $product->is_type('variable')) {
		$variation_id = $product->get_matching_variation($attributes);

		if ($variation_id) {
			$variation = new WC_Product_Variation($variation_id);
			$image_id = $variation->get_image_id();
			$image_url = wp_get_attachment_url($image_id);

			wp_send_json_success(array(
				'variation_id' => $variation_id,
				'price_html' => $variation->get_price_html(),
				'image_url' => $image_url,
			));
		}
	}

	wp_send_json_error(array('message' => 'No matching variation found.'));
	wp_die();
}

add_action('wp_ajax_get_variation_price', 'get_variation_price');
add_action('wp_ajax_nopriv_get_variation_price', 'get_variation_price');

function custom_woocommerce_add_to_cart()
{
    error_log('custom_woocommerce_add_to_cart triggered.');

    if (!function_exists('WC') || !WC()->cart) {
        error_log('WooCommerce is not initialized or cart is not available.');
        wp_send_json_error(['message' => 'WooCommerce is not initialized or cart is not available.']);
        wp_die();
    }

    if (!isset($_POST['product_id'])) {
        error_log('Missing product ID.');
        wp_send_json_error(['message' => 'Missing product ID.']);
        wp_die();
    }

    $product_id = intval($_POST['product_id']);
    $variation_id = isset($_POST['variation_id']) ? intval($_POST['variation_id']) : 0;
	$quantity = max(1, isset($_POST['quantity']) ? intval($_POST['quantity']) : 1);
    $gift_for = isset($_POST['gift_for']) ? sanitize_text_field($_POST['gift_for']) : '';
    $custom_amount = isset($_POST['custom_amount']) ? sanitize_text_field($_POST['custom_amount']) : '';

    error_log("Product ID: $product_id, Variation ID: $variation_id, Quantity: $quantity, Gift For: $gift_for, Custom Amount: $custom_amount");

    $product = wc_get_product($product_id);
    if (!$product) {
        error_log('Invalid product.');
        wp_send_json_error(['message' => 'Invalid product.']);
        wp_die();
    }

    $cart_item_data = [];

    if (!empty($gift_for)) {
        foreach (WC()->cart->get_cart() as $cart_item) {
            if (isset($cart_item['gift_for']) && $cart_item['gift_for'] != $gift_for) {
                error_log('Gift for mismatch in cart.');
                wp_send_json_error(['message' => 'You can gift to only one couple at a time.']);
                wp_die();
            }
        }
        $cart_item_data['gift_for'] = $gift_for;
        error_log('Gift for accepted: ' . $gift_for);
    }

	$variation_id = 0;
	if (!empty($custom_amount)) {
		if (!is_numeric($custom_amount) || $custom_amount <= 0) {
			wp_send_json_error(['message' => 'Invalid custom amount.']);
		}
		$cart_item_data['custom_price'] = floatval($custom_amount);
		$cart_item_data['unique_key'] = md5(microtime() . rand());
	} else {
		foreach ($attributes as $key => $val) {
			$cart_item_data['variation'][$key] = sanitize_text_field($val);
		}
		$variation_id = intval($_POST['variation_id']) ?: 0;
	}

    error_log('Variation Attributes: ' . json_encode($variation_attributes));

    $found_in_cart = false;
    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
        if (
            $cart_item['product_id'] == $product_id &&
            $cart_item['variation_id'] == $variation_id &&
            $cart_item['gift_for'] == $gift_for &&
            (isset($cart_item['variation']) ? $cart_item['variation'] : []) == $variation_attributes
        ) {
            WC()->cart->set_quantity($cart_item_key, $quantity);
            $found_in_cart = true;
            error_log('Product found in cart, updated quantity.');
            break;
        }
    }

    if (!$found_in_cart) {
        WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variation_attributes, $cart_item_data);
        error_log('Product added to cart.');
    }

    ob_start();
    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
        $_product = $cart_item['data'];
        $image = $_product->get_image_id() ? wp_get_attachment_url($_product->get_image_id()) : get_template_directory_uri() . '/assets/images/default_image.png';
        $title = $_product->get_title();
        $price = wc_price($_product->get_price());
        $total = wc_price($_product->get_price() * $cart_item['quantity']);

        $attributes_html = '';
        if (!empty($cart_item['variation'])) {
            $attributes_html .= '<ul class="wc-block-components-product-details">';
            foreach ($cart_item['variation'] as $name => $value) {
                $label = wc_attribute_label(str_replace('attribute_', '', $name));
                $attributes_html .= '<li><span class="wc-block-components-product-details__name">' . esc_html($label) . ':</span> <span class="wc-block-components-product-details__value">' . esc_html($value) . '</span></li>';
            }
            $attributes_html .= '</ul>';
        }

        echo '<tr class="wc-block-cart-items__row">
            <td class="wc-block-cart-item__image"><a href="' . get_permalink($cart_item['product_id']) . '"><img src="' . esc_url($image) . '" alt="' . esc_attr($title) . '"></a></td>
            <td class="wc-block-cart-item__product">
                <a class="wc-block-components-product-name" href="' . get_permalink($cart_item['product_id']) . '">' . esc_html($title) . '</a>
                <span class="price">' . $price . '</span>
                ' . $attributes_html . '
            </td>
            <td class="wc-block-cart-item__total">' . $total . '</td>
        </tr>';
    }
    $cart_items_html = ob_get_clean();

    $fragments = [
        '.wc-block-cart-items' => $cart_items_html,
        '.wc-block-components-totals-item__value' => WC()->cart->get_cart_total(),
    ];

    error_log('Sending JSON response with cart fragments.');
    wp_send_json_success(['fragments' => $fragments]);
    wp_die();
}
add_action('wp_ajax_custom_woocommerce_add_to_cart', 'custom_woocommerce_add_to_cart');
add_action('wp_ajax_nopriv_custom_woocommerce_add_to_cart', 'custom_woocommerce_add_to_cart');


add_filter('woocommerce_add_cart_item_data', 'add_registered_user_id_to_cart', 10, 2);
function add_registered_user_id_to_cart($cart_item_data, $product_id)
{
	if (is_user_logged_in()) {
		$user_id = get_current_user_id();
		$personalized_products = get_user_meta($user_id, '_personalized_products', true);

		// Check if the product is in the user's wishlist
		if (!empty($personalized_products) && in_array($product_id, $personalized_products)) {
			$cart_item_data['registered_user_id'] = $user_id;
		}
	}
	return $cart_item_data;
}

add_action('woocommerce_after_order_notes', 'add_original_user_id_field');

function add_original_user_id_field($checkout)
{
	if (isset($_GET['original_user_id'])) {
		$original_user_id = sanitize_text_field($_GET['original_user_id']);
		// error_log('Original User ID from URL: ' . $original_user_id);  // Debugging: Log the ID

		echo '<input type="hidden" name="original_user_id" value="' . esc_attr($original_user_id) . '">';
	}
}

add_action('woocommerce_checkout_create_order', 'save_original_user_id_in_order_meta', 10, 2);
function save_original_user_id_in_order_meta($order, $data)
{
	if (isset($_POST['original_user_id'])) {
		$original_user_id = intval($_POST['original_user_id']);  // Extract the ID from the POST reques
		$order->update_meta_data('_wc_order_attribution_session_entry', $original_user_id);
	}
}

add_action('woocommerce_thankyou', 'send_email_on_order_complete', 10, 1);

add_action('woocommerce_checkout_before_customer_details', 'add_deliver_to_couple_checkbox_before_billing');

function add_deliver_to_couple_checkbox_before_billing()
{
	echo '<div class="form-row form-row-wide" id="deliver_to_couple_field">';

	woocommerce_form_field('deliver_to_couple', array(
		'type' => 'checkbox',
		'label' => __('Ship To Couple', 'woocommerce'),
		'label_class' => array('custom-checkbox'),
		'class' => array('form-row-wide'),
		'required' => false,
	), WC()->checkout->get_value('deliver_to_couple'));

	echo '</div>';
}

function save_deliver_to_couple_order_meta($order, $data)
{
	$deliver_to_couple = isset($_POST['deliver_to_couple']) ? 'yes' : 'no';
	$order->update_meta_data('deliver_to_couple', $deliver_to_couple);
}
add_action('woocommerce_checkout_create_order', 'save_deliver_to_couple_order_meta', 10, 2);


add_action('woocommerce_admin_order_data_after_billing_address', 'display_deliver_to_couple_admin_order_meta', 10, 1);
function display_deliver_to_couple_admin_order_meta($order)
{
	$deliver_to_couple = $order->get_meta('deliver_to_couple');
	$display_value = ($deliver_to_couple === 'yes') ? 'Yes' : 'No';
	echo '<p><strong>' . __('Ship To Couple') . ':</strong> ' . $display_value . '</p>';
	$gift_message = $order->get_meta('gift_message');
	if (!empty($gift_message)) {
		echo '<p><strong>' . __('Gift Message', 'woocommerce') . ':</strong><br>' . $gift_message . '</p>';
	}
}

add_filter('woocommerce_ship_to_different_address_checked', '__return_false');

add_filter('template_include', 'override_woocommerce_single_product_template', 100);
function override_woocommerce_single_product_template($template)
{
	if (is_singular('product')) {
		return get_stylesheet_directory() . '/woocommerce/single-product.php';
	}
	if (is_product_category()) {
		// wp_redirect(get_permalink(wc_get_page_id('shop')));
		return get_stylesheet_directory() . '/woocommerce/archive-product.php';
	}
	if (is_tax('brand')) {
		// Use the same template as product categories
		$template = locate_template('woocommerce/archive-product.php');
	}
	return $template;
}

// Banner image 
function my_banner_images_admin_scripts($hook)
{
	if ($hook !== 'toplevel_page_banner-images-settings') {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script('banner-images-script', get_template_directory_uri() . '/banner-images.js', ['jquery'], null, true);
}
add_action('admin_enqueue_scripts', 'my_banner_images_admin_scripts');

function my_banner_images_settings_page()
{
	add_menu_page(
		'Banner Images',
		'Banner Images',
		'manage_options',
		'banner-images-settings',
		'my_banner_images_settings_callback',
		'dashicons-format-image',
		20
	);
}
add_action('admin_menu', 'my_banner_images_settings_page');

function my_banner_images_settings_callback()
{
	?>
	<div class="wrap">
		<h1>Choose Banner Images</h1>
		<form method="post" action="options.php">
			<?php
			settings_fields('banner_images_group');
			do_settings_sections('banner-images-settings');
			submit_button();
			?>
		</form>
	</div>
	<?php
}

function my_banner_images_settings_init()
{
	register_setting('banner_images_group', 'banner_images');

	add_settings_section('banner_images_section', 'Select Four Images', null, 'banner-images-settings');

	for ($i = 1; $i <= 4; $i++) {
		add_settings_field(
			"banner_image_$i",
			"Banner Image $i",
			function () use ($i) {
				$banner_images = get_option('banner_images', []);
				$image_id = isset($banner_images[$i]) ? intval($banner_images[$i]) : '';
				$image_url = $image_id ? wp_get_attachment_url($image_id) : '';

				?>
			<input type="hidden" id="banner_image_<?php echo $i; ?>" name="banner_images[<?php echo $i; ?>]"
				value="<?php echo $image_id; ?>">
			<button type="button" class="upload-banner-image button" data-target="banner_image_<?php echo $i; ?>">Choose
				Image</button>
			<button type="button" class="remove-banner-image button"
				style="display: <?php echo $image_id ? 'inline-block' : 'none'; ?>;">Remove</button>
			<br><br>
			<img id="preview_banner_image_<?php echo $i; ?>" src="<?php echo esc_url($image_url); ?>"
				style="max-width:150px; <?php echo $image_url ? '' : 'display:none;'; ?>">
			<?php
			},
			'banner-images-settings',
			'banner_images_section'
		);
	}
}
add_action('admin_init', 'my_banner_images_settings_init');

function custom_empty_cart_message()
{
	if (wc_get_page_id('shop') > 0) {
		echo '<div class="custom-empty-cart">';
		echo '<h2>Your cart is empty!</h2>';
		echo '<p>Explore our products and add items to your cart.</p>';
		echo '<a href="' . esc_url(wc_get_page_permalink('shop')) . '" class="button">Shop Now</a>';
		echo '</div>';
	}
}
add_action('woocommerce_cart_is_empty', 'custom_empty_cart_message');

add_filter('body_class', function ($classes) {
	if (WC()->cart->is_empty()) {
		$classes[] = 'cart-is-empty';
	} else {
		$classes[] = 'cart-has-items';
	}
	return $classes;
});


// After change password redirect to login page 
add_action('woocommerce_before_customer_login_form', function () {
	if (isset($_GET['password_change']) && $_GET['password_change'] == 'true') {
		wc_add_notice("Password changed successfully! Please log in with your new password.", "success");
	}
});



// // After registration redirect to login page with success message 
function redirect_after_registration($user_id)
{
	if (!is_admin()) {
		wp_safe_redirect(site_url('/wishlist/'));
	}
}
add_action('user_register', 'redirect_after_registration');

function display_registration_success_message()
{
	if (isset($_GET['registration']) && $_GET['registration'] == 'success') {
		echo '<div class="woocommerce-message">Registration successful! Please log in.</div>';
	}
}
add_action('woocommerce_before_customer_login_form', 'display_registration_success_message');

add_filter('woocommerce_default_address_fields', function ($fields) {
	if (is_checkout()) {
		foreach ($fields as $key => $field) {
			if (strpos($key, 'shipping_') !== false) {
				$fields[$key]['required'] = false;
			}
		}
	}
	return $fields;
}, 20);

add_filter('woocommerce_billing_fields', function ($fields) {
	foreach ($fields as $key => $field) {
		$fields[$key]['required'] = true;
	}
	return $fields;
});

function save_gift_recipient_order_item_meta($item_id, $item, $order_id)
{
	if ($item->get_meta('gift_for')) {
		return;
	}

	if (isset($item->legacy_values['gift_for'])) {
		$item->add_meta_data('gift_for', $item->legacy_values['gift_for'], true);
		$item->save();
	}
}
add_action('woocommerce_new_order_item', 'save_gift_recipient_order_item_meta', 10, 3);


function custom_woocommerce_registration_redirect($redirect)
{
	if (current_user_can('seller')) {
		$redirect_url = home_url('/dashboard/');
	} else {
		$redirect_url = home_url('/wishlist/');
	}
	return $redirect_url;
}
add_filter('woocommerce_registration_redirect', 'custom_woocommerce_registration_redirect');

function custom_woocommerce_login_redirect($redirect, $user)
{
	if (!is_admin()) {
		if (in_array('seller', (array) $user->roles)) {
			$custom_redirect_url = home_url('/dashboard/');
		} else {
			$custom_redirect_url = home_url('/wishlist/');
		}
	}
	return $custom_redirect_url;
}
add_filter('woocommerce_login_redirect', 'custom_woocommerce_login_redirect', 10, 2);

// gift this product
function add_gift_recipient_to_cart_item_data($cart_item_data, $product_id, $variation_id)
{
	if (isset($_POST['gift_for']) && !empty($_POST['gift_for'])) {
		$cart_item_data['gift_for'] = sanitize_text_field($_POST['gift_for']);
	}
	return $cart_item_data;
}
add_filter('woocommerce_add_cart_item_data', 'add_gift_recipient_to_cart_item_data', 10, 3);

function display_gift_recipient_in_cart($item_data, $cart_item)
{
	if (isset($cart_item['gift_for'])) {
		$user_info = get_userdata($cart_item['gift_for']);
		$first_name = get_user_meta($cart_item['gift_for'], 'first_name', true);
		$last_name = get_user_meta($cart_item['gift_for'], 'partner_fname', true);
		// var_dump($user_info);
		if ($user_info) {
			$item_data[] = array(
				'key' => __('Gift For', 'woocommerce'),
				'value' => $first_name . ' & ' . $last_name,
				'display' => '',
			);
		}
		if (isset($cart_item['custom_price'])) {
			$item_data[] = array(
				'key'     => 'Custom Price',
				'value'   => wc_price($cart_item['custom_price']),
				'display' => '',
			);
		}
		$hidden_value = 'custom_value';
		WC()->session->set('gift_user_id', $cart_item['gift_for']);
	}
	return $item_data;
}
add_filter('woocommerce_get_item_data', 'display_gift_recipient_in_cart', 10, 2);

// Add info icon next to Platform Fees in Cart & Checkout
add_filter('woocommerce_cart_totals_fee_html', function ($fee_html, $fee) {
	if (strpos(strtolower($fee->name), 'platform fee') !== false) {
		$info_icon = '<div class="tooltip"><i class="fal fa-info-circle"></i><span class="tooltiptext">This fee covers platform maintenance and services.</span></div>';
		$fee_html .= ' ' . $info_icon;
	}
	return $fee_html;
}, 10, 2);

// Add info icon in Order Summary on Checkout Page
add_filter('woocommerce_get_order_item_totals', function ($total_rows, $order) {
    foreach ($total_rows as $key => $row) {
        if (strpos(strtolower($row['label']), 'platform fee') !== false) {
            $info_icon = 'This fee covers platform maintenance and services.';
            $total_rows[$key]['label'] .= ' ' . $info_icon;
			 $total_rows[$key]['sanitize'] = false;
        }
    }
    return $total_rows;
}, 10, 2);


// Wishlist custom profile image auto upload code
function update_user_profile_picture()
{
	// Check security nonce
	//check_ajax_referer('update_profile_picture_nonce', 'security');
	if (!is_user_logged_in()) {
		wp_send_json_error(['message' => 'User not logged in']);
	}
	$user_id = get_current_user_id();
	if (!empty($_FILES['profile_picture']['name'])) {
		$uploaded_file = wp_handle_upload($_FILES['profile_picture'], ['test_form' => false]);
		if (!isset($uploaded_file['error'])) {
			$image_url = $uploaded_file['url'];
			update_user_meta($user_id, 'profile_picture', $image_url);
			wp_send_json_success(['image_url' => $image_url]);
		} else {
			wp_send_json_error(['message' => 'File upload error']);
		}
	} else {
		wp_send_json_error(['message' => 'No file uploaded']);
	}
}
add_action('wp_ajax_update_user_profile_picture', 'update_user_profile_picture');
add_action('wp_ajax_nopriv_update_user_profile_picture', 'update_user_profile_picture');

add_filter('woocommerce_checkout_redirect_empty_cart', '__return_false');

add_filter('woocommerce_get_checkout_url', function ($url) {
	if (is_page('checkout3')) {
		return get_permalink(get_page_by_path('checkout3'));
	}
	return $url;
});

add_filter('woocommerce_get_checkout_url', function ($url) {
	if (is_page('checkout3')) {
		return get_permalink(get_page_by_path('checkout3'));
	}
	return $url;
});


function disable_woocommerce_checkout_scripts()
{
	if (is_checkout()) {
		wp_dequeue_script('wc-checkout');
	}
}
add_action('wp_enqueue_scripts', 'disable_woocommerce_checkout_scripts', 99);


add_action('wp_footer', function () {
	if (is_page('checkout3')) {
		?>
		<script>
			jQuery(document).ready(function ($) {
				wc_checkout_params = {
					ajax_url: "<?php echo esc_url(admin_url('admin-ajax.php')); ?>",
					is_checkout: true
				};
			});
		</script>
		<?php
	}
});

add_action('wp_footer', function () {
	?>
	<script>
		jQuery(document).ready(function ($) {
			function disableLoaderAndEnableButton() {
				setTimeout(function () {
					$('.blockUI, .woocommerce-checkout-review-order .blockUI, .processing').hide();
					$('#place_order').prop('disabled', false);
				}, 300);
			}
			function handleAutofill() {
				setTimeout(function () {
					if (!$('.woocommerce-invalid').length) {
						disableLoaderAndEnableButton();
					}
				}, 800);
			}
			disableLoaderAndEnableButton();
			$(document).on('updated_checkout', function () {
				handleAutofill();
			});
			$('input, select').on('change', function () {
				handleAutofill();
			});
			$(document).on('change', 'input[name="payment_method"]', function () {
				disableLoaderAndEnableButton();
			});
			$(document).on('ajaxStart', function () {
				$('.blockUI, .woocommerce-checkout-review-order .blockUI, .processing').hide();
			});
			$(document).on('ajaxStop', function () {
				disableLoaderAndEnableButton();
			});
		});
		jQuery(document).ready(function ($) {
			$('#place_order').prop('disabled', false); // Ensure button is enabled

			$('#place_order').on('click', function (e) {
				e.preventDefault(); // Prevent default button behavior
				$(this).prop('disabled', true); // Disable to prevent multiple clicks

				if ($('.woocommerce-invalid').length > 0) {
					alert("Please fill in required fields.");
					$(this).prop('disabled', false);
					return;
				}

				$('form.checkout').submit(); // Force form submission
			});
		});

	</script>
	<?php
});

add_filter('woocommerce_checkout_process', function () {
	wc_add_notice('Processing order, please wait...', 'notice');
}, 10);

function load_wc_scripts()
{
	if (is_checkout()) {
		// echo "called";
		wp_enqueue_script('wc-checkout');
	}
}
add_action('wp_enqueue_scripts', 'load_wc_scripts');


// function process_custom_checkout()
// {
//     error_log('Function process_custom_checkout() started.');

//     if (!isset($_POST['billing_first_name']) || !isset($_POST['billing_email'])) {
//         error_log('Missing required fields: First Name or Email.');
//         wp_send_json_error(['message' => 'Missing required fields.']);
//     }

//     error_log('All required fields are present.');

//     $first_name = sanitize_text_field($_POST['billing_first_name']);
//     $last_name = sanitize_text_field($_POST['billing_last_name']);
//     $email = sanitize_email($_POST['billing_email']);
//     $phone = sanitize_text_field($_POST['billing_phone']);

//     error_log("First Name: $first_name, Email: $email");

//     // Create order
//     $order = wc_create_order();
//     if (!$order) {
//         error_log('Failed to create WooCommerce order.');
//         wp_send_json_error(['message' => 'Order creation failed.']);
//     }

//     error_log("Order created successfully. Order ID: " . $order->get_id());

//     foreach (WC()->cart->get_cart() as $cart_item) {
//         $product_id = $cart_item['product_id'];
//         $quantity = $cart_item['quantity'];
//         $order_item_id = $order->add_product(wc_get_product($product_id), $quantity);

//         error_log("Added product $product_id (Qty: $quantity) to order.");

//         if (!empty($cart_item['gift_for'])) {
//             wc_add_order_item_meta($order_item_id, '_gift_for', $cart_item['gift_for']);
//             error_log("Added gift_for meta for product ID: $product_id");
//         }
//     }

//     // Set billing and shipping details
//     $order->set_address([
//         'first_name' => $first_name,
//         'last_name'  => $last_name,
//         'email'      => $email,
//         'phone'      => $phone,
//         'address_1'  => sanitize_text_field($_POST['billing_address_1']),
//         'address_2'  => sanitize_text_field($_POST['billing_address_2']),
//         'city'       => sanitize_text_field($_POST['billing_city']),
//         'state'      => sanitize_text_field($_POST['billing_state']),
//         'postcode'   => sanitize_text_field($_POST['billing_postcode']),
//         'country'    => sanitize_text_field($_POST['billing_country']),
//     ], 'billing');

//     error_log("Billing details set.");

//     $order->set_address([
//         'first_name' => sanitize_text_field($_POST['shipping_first_name']),
//         'last_name'  => sanitize_text_field($_POST['shipping_last_name']),
//         'address_1'  => sanitize_text_field($_POST['shipping_address_1']),
//         'address_2'  => sanitize_text_field($_POST['shipping_address_2']),
//         'city'       => sanitize_text_field($_POST['shipping_city']),
//         'state'      => sanitize_text_field($_POST['shipping_state']),
//         'postcode'   => sanitize_text_field($_POST['shipping_postcode']),
//         'country'    => sanitize_text_field($_POST['shipping_country']),
//     ], 'shipping');

//     error_log("Shipping details set.");

//     $deliver_to_couple = isset($_POST['deliver_to_couple']) ? 'yes' : 'no';
//     $order->update_meta_data('_deliver_to_couple', $deliver_to_couple);
//     $order->set_customer_note(sanitize_textarea_field($_POST['order_comments']));

//     error_log("Order meta data updated.");

//     // Calculate totals and set payment status
//     $order->calculate_totals();
//     $order->set_status('processing'); 
//     $order->save();

//     error_log("Order totals calculated and status set.");

//     // Empty cart
//     WC()->cart->empty_cart();
//     error_log("Cart emptied.");

//     // Redirect to Thank You page
//     $thank_you_url = $order->get_checkout_order_received_url();
//     error_log("Redirecting to Thank You page: $thank_you_url");

//     wp_send_json_success(['redirect' => $thank_you_url]);

//     exit();
// }

function process_custom_checkout()
{
	if (!isset($_POST['billing_first_name']) || !isset($_POST['billing_email'])) {
		wp_send_json_error(['message' => 'Missing required fields.']);
	}

	$first_name = sanitize_text_field($_POST['billing_first_name']);
	$last_name = sanitize_text_field($_POST['billing_last_name']);
	$email = sanitize_email($_POST['billing_email']);
	$phone = sanitize_text_field($_POST['billing_phone']);
	$address_1 = sanitize_text_field($_POST['billing_address_1']);
	$address_2 = sanitize_text_field($_POST['billing_address_2']);
	$city = sanitize_text_field($_POST['billing_city']);
	$state = sanitize_text_field($_POST['billing_state']);
	$postcode = sanitize_text_field($_POST['billing_postcode']);
	$country = sanitize_text_field($_POST['billing_country']);
	$order_notes = sanitize_textarea_field($_POST['order_comments']);
	$deliver_to_couple = isset($_POST['deliver_to_couple']) ? 'yes' : 'no';

	// Create order
	$order = wc_create_order();

	foreach (WC()->cart->get_cart() as $cart_item) {
		$product_id = $cart_item['product_id'];
		$quantity = $cart_item['quantity'];
		$order_item_id = $order->add_product(wc_get_product($product_id), $quantity);

		if (!empty($cart_item['gift_for'])) {
			wc_add_order_item_meta($order_item_id, 'gift_for', $cart_item['gift_for']);
		}
	}

	// Set billing details
	$order->set_address([
		'first_name' => $first_name,
		'last_name' => $last_name,
		'email' => $email,
		'phone' => $phone,
		'address_1' => $address_1,
		'address_2' => $address_2,
		'city' => $city,
		'state' => $state,
		'postcode' => $postcode,
		'country' => $country,
	], 'billing');

	// Set shipping details
	$shipping_first_name = sanitize_text_field($_POST['shipping_first_name']);
	$shipping_last_name = sanitize_text_field($_POST['shipping_last_name']);
	$shipping_address_1 = sanitize_text_field($_POST['shipping_address_1']);
	$shipping_address_2 = sanitize_text_field($_POST['shipping_address_2']);
	$shipping_city = sanitize_text_field($_POST['shipping_city']);
	$shipping_state = sanitize_text_field($_POST['shipping_state']);
	$shipping_postcode = sanitize_text_field($_POST['shipping_postcode']);
	$shipping_country = sanitize_text_field($_POST['shipping_country']);

	$order->set_address([
		'first_name' => $shipping_first_name,
		'last_name' => $shipping_last_name,
		'address_1' => $shipping_address_1,
		'address_2' => $shipping_address_2,
		'city' => $shipping_city,
		'state' => $shipping_state,
		'postcode' => $shipping_postcode,
		'country' => $shipping_country,
	], 'shipping');

	$order->update_meta_data('_deliver_to_couple', $deliver_to_couple);
	$order->set_customer_note($order_notes);

	// Calculate totals and set payment status
	$order->calculate_totals();
	$order->set_status('processing'); // Change to 'completed' if no payment needed
	$order->save();

	//wp_schedule_single_event(time() + 10, 'send_order_email_event', [$order->get_id()]);


	WC()->cart->empty_cart();

	// Redirect to Thank You page
	ob_end_clean(); // Clear output buffer

	$thank_you_url = $order->get_checkout_order_received_url();
	wp_send_json_success(['redirect' => $thank_you_url]);

	exit();
}
add_action('wp_ajax_process_custom_checkout', 'process_custom_checkout');
add_action('wp_ajax_nopriv_process_custom_checkout', 'process_custom_checkout');

function shipping_address_filled()
{
	$user_id = get_current_user_id();
	$required_fields = [
		get_user_meta($user_id, 'shipping_street', true),
		get_user_meta($user_id, 'shipping_city', true),
		get_user_meta($user_id, 'shipping_zipcode', true),
		get_user_meta($user_id, 'shipping_country', true),
		get_user_meta($user_id, 'shipping_state', true),
	];
	foreach ($required_fields as $field) {
		if (empty($field)) {
			wp_send_json_error(['message' => 'Missing required shipping info']);
		}
	}
	wp_send_json_success(['message' => 'All shipping fields are filled']);
}

add_action('wp_ajax_shipping_address_filled', 'shipping_address_filled');
add_action('wp_ajax_nopriv_shipping_address_filled', 'shipping_address_filled');

// add_filter('woocommerce_email_enabled_customer_processing_order', '__return_false');
// checkbok
add_action('wp_footer', function () {
	if (is_checkout() && !is_order_received_page()) {
		?>
		<script>
			jQuery(document).ready(function ($) {
				function showNotification(message, callback) {
					let notification = document.createElement("div");
					notification.className = "custom-notification";
					notification.innerHTML = `
						<div class="notification-content">
							<p>${message}</p>
							<button class="notification-btn">OK</button>
						</div>
					`;
					document.body.appendChild(notification);
					document.body.classList.add("open-modal");

					document.querySelector(".notification-btn").addEventListener("click", function () {
						document.body.removeChild(notification);
						document.body.classList.remove("open-modal");
						if (callback) callback();
					});
				}
				let coupleShippingData = {};

				// Function to auto-fill shipping fields
				function autofillShippingFields(data) {
					$('#shipping_first_name').val(data.first_name);
					$('#shipping_last_name').val(data.last_name);
					$('#shipping_address_1').val(data.shipping_address_1);
					$('#shipping_city').val(data.shipping_city);
					$('#shipping_postcode').val(data.shipping_postcode);
					$('#shipping_country').val(data.shipping_country);
					$('#shipping_state').val(data.shipping_state).trigger('change');
				}

				// Fetch gift recipient shipping details via AJAX
				$.ajax({
					url: '<?php echo admin_url("admin-ajax.php"); ?>',
					type: 'POST',
					data: { action: 'get_gift_for_shipping' },
					success: function (response) {
						coupleShippingData = response.data;
						if (!coupleShippingData.first_name ||
							!coupleShippingData.last_name ||
							!coupleShippingData.shipping_address_1 ||
							!coupleShippingData.shipping_city ||
							!coupleShippingData.shipping_postcode ||
							!coupleShippingData.shipping_country ||
							!coupleShippingData.shipping_state) {
							showNotification("⚠️ Please contact the couple to fill their shipping address.");
							$('#deliver_to_couple').prop('checked', false);
							$('.shipping_address').css('display', 'block');
						} else {
							autofillShippingFields(coupleShippingData);
							$('#deliver_to_couple').prop('checked', true);
						}
					}
				});

				// Handle checkbox change
				$('#deliver_to_couple').change(function () {
					const checkbox = $(this);
					if ($(this).is(':checked')) {
						console.log("Checkbox Checked:", coupleShippingData); // Debug log
						if (coupleShippingData && Object.keys(coupleShippingData).length > 0) {
							autofillShippingFields(coupleShippingData);
							const sameAsBillingCheckbox = document.querySelector("input[name='same_as_billing']");
							const sameAsBillingLabel = document.querySelector("label.same_as_billing_label");

							if (sameAsBillingCheckbox && sameAsBillingLabel) {
								sameAsBillingCheckbox.style.display = "none";
								sameAsBillingLabel.style.display = "none";
								sameAsBillingCheckbox.checked = false;
							}
						} else {
							showNotification("⚠️ No saved address found for the recipient.");
							$(this).prop('checked', false);
							address_same_as_billing();
						}
					} else {
						$('.shipping_address').css('display', 'none');
						showNotificationWithTwoButton(
							"<h3>Are you sure you don’t want to ship your gifts directly to the couple’s preferred address?</h3>" +
							"<p>PS: Our newlyweds love the convenience of having items shipped directly to their doorstep!</p>",
							function () {
								// OK clicked → Clear shipping fields
								$('.shipping_address').css('display', 'block');
								$('#shipping_first_name, #shipping_last_name, #shipping_address_1, #shipping_city, #shipping_postcode, #shipping_country, #shipping_state').val('');
								address_same_as_billing();
							},
							function () {
								// Cancel clicked → Keep checkbox checked & autofill
								$(this).prop('checked', true);
								$('.shipping_address').css('display', 'none');
								autofillShippingFields(coupleShippingData);
								$(this).prop('checked', true);
								checkbox.prop('checked', true);

								const sameAsBillingCheckbox = document.querySelector("input[name='same_as_billing']");
								const sameAsBillingLabel = document.querySelector("label.same_as_billing_label");

								if (sameAsBillingCheckbox && sameAsBillingLabel) {
									sameAsBillingCheckbox.style.display = "none";
									sameAsBillingLabel.style.display = "none";
									sameAsBillingCheckbox.checked = false;
								}
							}
						);
					}
				});
				function address_same_as_billing() {
					const sameAsBillingCheckbox = document.querySelector("input[name='same_as_billing']");
					const sameAsBillingLabel = document.querySelector("label.same_as_billing_label");

					if (sameAsBillingCheckbox && sameAsBillingLabel) {
						sameAsBillingCheckbox.style.display = "inline-block";
						sameAsBillingLabel.style.display = "inline-block"; // also show label
						sameAsBillingCheckbox.checked = false;
					}

					const billingFirstName = document.querySelector("input[name='billing_first_name']").value;
					const billingLastName = document.querySelector("input[name='billing_last_name']").value;
					const billingAddress = document.querySelector("input[name='billing_address_1']").value;
					const billingCity = document.querySelector("input[name='billing_city']").value;
					const billingPostcode = document.querySelector("input[name='billing_postcode']").value;
					const billingState = document.querySelector("select[name='billing_state']").value;

					// Store the billing details in local storage
					const billingData = {
						billingFirstName,
						billingLastName,
						billingAddress,
						billingCity,
						billingPostcode,
						billingState
					};

					localStorage.setItem('billingData', JSON.stringify(billingData));

					if (sameAsBillingCheckbox.checked) {
						autoFillShippingDetails();
					}
				}
			});
		</script>
		<?php
	}
});

function get_gift_for_shipping()
{
	$gift_user_data = [];
	foreach (WC()->cart->get_cart() as $cart_item) {
		if (!empty($cart_item['gift_for'])) {
			$gift_user_id = $cart_item['gift_for'];
			$user_info = get_userdata($gift_user_id);
			$gift_user_data = [
				'first_name' => $user_info->first_name,
				'last_name' => $user_info->last_name,
				'shipping_address_1' => get_user_meta($gift_user_id, 'shipping_street', true),
				'shipping_city' => get_user_meta($gift_user_id, 'shipping_city', true),
				'shipping_postcode' => get_user_meta($gift_user_id, 'shipping_zipcode', true),
				'shipping_country' => get_user_meta($gift_user_id, 'shipping_country', true),
				'shipping_state' => get_user_meta($gift_user_id, 'shipping_state', true),
			];
			break;
		}
		// var_dump($gift_user_data);
	}

	if (
		!empty($gift_user_data['first_name']) &&
		!empty($gift_user_data['last_name']) &&
		!empty($gift_user_data['shipping_address_1']) &&
		!empty($gift_user_data['shipping_city']) &&
		!empty($gift_user_data['shipping_postcode']) &&
		!empty($gift_user_data['shipping_country']) &&
		!empty($gift_user_data['shipping_state'])
	) {
		wp_send_json_success($gift_user_data);
	} {
		wp_send_json_error(['message' => 'No saved shipping address.']);
	}
}
add_action('wp_ajax_get_gift_for_shipping', 'get_gift_for_shipping');
add_action('wp_ajax_nopriv_get_gift_for_shipping', 'get_gift_for_shipping');

add_action('woocommerce_email_after_order_table', function ($order, $sent_to_admin, $plain_text, $email) {
	if ($sent_to_admin) {
		$shipping_address = $order->get_shipping_address_1() ? nl2br($order->get_formatted_shipping_address()) : 'No shipping address provided.';
		echo '<h3>' . __('Shipping Address', 'woocommerce') . '</h3>';
		echo '<address style=" text-align: left; margin-bottom:20px; padding:12px;color:#414141;border:1px solid #e5e5e5">' . $shipping_address . '</address>';
	}
}, 20, 4);

// add_action('woocommerce_checkout_order_processed', function ($order_id) {
// 	$order = wc_get_order($order_id);
// 	WC()->mailer()->emails['WC_Email_New_Order']->trigger($order_id);
// }, 20);

// Transfer to cash
function register_custom_order_status()
{
	register_post_status('wc-transfer', array(
		'label' => 'Transfer',
		'public' => true,
		'exclude_from_search' => false,
		'show_in_admin_all_list' => true,
		'show_in_admin_status_list' => true,
		'label_count' => _n_noop('Transfer <span class="count">(%s)</span>', 'Transfer <span class="count">(%s)</span>')
	));
	register_post_status('wc-confirm', array(
		'label' => 'confirm',
		'public' => true,
		'exclude_from_search' => false,
		'show_in_admin_all_list' => true,
		'show_in_admin_status_list' => true,
		'label_count' => _n_noop('Confirm <span class="count">(%s)</span>', 'Confirm <span class="count">(%s)</span>')
	));
}
add_action('init', 'register_custom_order_status');

// add_action('template_redirect', function () {
//     if (is_checkout() && !is_wc_endpoint_url('order-received')) {
//         wp_redirect(home_url()); // Redirect to homepage or custom page
//         exit;
//     }
// });

// Display the gift status in the new custom column for order items
add_action('woocommerce_admin_order_item_values', 'display_gift_status_in_column', 10, 3);
function display_gift_status_in_column($item_id, $item, $order)
{
	if (is_array($item_id) && isset($item_id['id'])) {
		$order_item_id = $item->get_id();
	} else {
		$order_item_id = $item->get_id();
	}
	$gift_status = wc_get_order_item_meta($order_item_id, '_gift_status', true);
	if (empty($gift_status)) {
		$gift_status = 'Pending';
	}
	echo '<td class="gift-status-column">' . esc_html($gift_status) . '</td>';
}

add_action('pre_get_posts', function ($query) {
	if (!is_admin() && $query->is_main_query() && is_tax('product_cat')) {
		if (isset($_GET['brand']) && !empty($_GET['brand'])) {
			$brand_slug = sanitize_text_field($_GET['brand']);
			$tax_query = $query->get('tax_query');

			$tax_query[] = array(
				'taxonomy' => 'brand', // Make sure this is your correct taxonomy slug
				'field' => 'slug',
				'terms' => $brand_slug,
			);

			$query->set('tax_query', $tax_query);
		}
	}
});

// Handle the AJAX request to add product to cart with variations and quantity
add_action('wp_ajax_add_to_cart_with_variations', 'add_to_cart_with_variations');
add_action('wp_ajax_nopriv_add_to_cart_with_variations', 'add_to_cart_with_variations');

function add_to_cart_with_variations()
{
	if (isset($_POST['product_id'], $_POST['quantity'])) {
		$product_id = intval($_POST['product_id']);
		$attributes = isset($_POST['attributes']) ? json_decode(stripslashes($_POST['attributes']), true) : [];
		$quantity = intval($_POST['quantity']);
		$gift_for = isset($_POST['gift_for']) ? sanitize_text_field($_POST['gift_for']) : '';
		$custom_amount = isset($_POST['custom_amount']) ? floatval($_POST['custom_amount']) : 0;

		$product = wc_get_product($product_id);
		if (!$product) {
			wp_send_json_error(array('message' => 'Invalid product.'));
		}

		$variation_id = 0;
		$cart_item_data = [];

		if (!empty($gift_for)) {
			foreach (WC()->cart->get_cart() as $cart_item) {
				if (isset($cart_item['gift_for']) && $cart_item['gift_for'] !== $gift_for) {
					wp_send_json_error(array('message' => 'You can gift to only one couple at a time.'));
				}
			}
			$cart_item_data['gift_for'] = $gift_for;
		}

		// Handle custom price (for Lifafa/cash product)
		if ($custom_amount > 0) {
			$cart_item_data['custom_price'] = $custom_amount;
			$variation_data = ['Custom amount' => wc_price($custom_amount)];
			$cart_item_data['variation'] = $variation_data;
		} else {
			// Use variation matching if no custom price
			if ($product->is_type('variable')) {
				$variation_id = find_matching_variation_id($product, $attributes);
				$cart_item_data['variation'] = $attributes;
			}
		}

		// Check if product already in cart
		foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
			if (
				$cart_item['product_id'] == $product_id &&
				$cart_item['variation_id'] == $variation_id &&
				(isset($cart_item['gift_for']) ? $cart_item['gift_for'] : '') === $gift_for &&
				$cart_item['variation'] == $cart_item_data['variation']
			) {
				WC()->cart->set_quantity($cart_item_key, $quantity);
				wp_send_json_success(array('message' => 'Product quantity updated in cart.'));
			}
		}

		// Add to cart
		WC()->cart->add_to_cart($product_id, $quantity, $variation_id, [], $cart_item_data);
		wp_send_json_success(array('message' => 'Product added to cart.'));
	} else {
		wp_send_json_error(array('message' => 'Missing required fields.'));
	}
}


// Function to find matching variation ID
function find_matching_variation_id($product, $attributes)
{
	$available_variations = $product->get_available_variations();
	foreach ($available_variations as $variation) {
		$match = true;
		foreach ($attributes as $attribute_name => $attribute_value) {
			if (isset($variation['attributes'][$attribute_name]) && $variation['attributes'][$attribute_name] !== $attribute_value) {
				$match = false;
				break;
			}
		}

		if ($match) {
			return $variation['variation_id'];
		}
	}
	return false;
}

add_action('woocommerce_cleanup_sessions', function () {
	global $wpdb;
	$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_wc_session_%'");
});

add_filter('woocommerce_billing_fields', function ($fields) {
	unset($fields['billing_company']);
	return $fields;
});

add_filter('woocommerce_checkout_fields', function ($fields) {
	// Remove required attribute from phone number
	if (isset($fields['billing']['billing_phone'])) {
		$fields['billing']['billing_phone']['required'] = false;
	}
	return $fields;
});

add_filter('woocommerce_checkout_fields', function ($fields) {
	$fields['billing']['billing_email']['priority'] = 1;
	$fields['billing']['billing_first_name']['priority'] = 10;
	$fields['billing']['billing_last_name']['priority'] = 20;
	$fields['billing']['billing_phone']['priority'] = 30;
	$fields['billing']['billing_address_1']['priority'] = 40;
	$fields['billing']['billing_address_2']['priority'] = 50;
	$fields['billing']['billing_city']['priority'] = 60;
	$fields['billing']['billing_postcode']['priority'] = 70;
	$fields['billing']['billing_country']['priority'] = 80;
	$fields['billing']['billing_state']['priority'] = 90;

	return $fields;
});

add_filter('woocommerce_checkout_fields', 'remove_company_name_from_shipping');

function remove_company_name_from_shipping($fields)
{
	unset($fields['shipping']['shipping_company']); // Remove Company Name from Shipping
	return $fields;
}

// add_filter('woocommerce_add_to_cart_validation', function ($passed, $product_id, $quantity) {
//     if (!isset($_GET['_gift_for']) || empty($_GET['_gift_for'])) {
//         wc_add_notice(__('No couple selected for this gift.'), 'error');
//         return false; 
//     }
//     return $passed;
// }, 10, 3);

function redirect_logged_in_users_from_signup()
{
	if (is_page('sign-up') && is_user_logged_in()) {
		wp_redirect(home_url('/modernlifafa-elementor/wishlist/'));
		exit;
	}
}
add_action('template_redirect', 'redirect_logged_in_users_from_signup');

function redirect_guest_users_from_wishlist()
{
	if (is_page('wishlist')) {
		// if (!is_user_logged_in()) {
		//     wp_redirect(home_url());
		//     exit;
		// }

		if (isset($_GET['original_user_id'])) {
			$original_user_id = intval($_GET['original_user_id']);

			if (!get_user_by('ID', $original_user_id)) {
				setcookie('wishlist_error', 'No user exists with this ID.', time() + 10, "/");
				wp_redirect(home_url());
				exit;
			}
		}
	}
}
add_action('template_redirect', 'redirect_guest_users_from_wishlist');

function display_toastr_notification()
{
	if (isset($_COOKIE['wishlist_error'])) {
		?>
		<script type="text/javascript">
			jQuery(document).ready(function ($) {
				toastr.error("<?php echo esc_js($_COOKIE['wishlist_error']); ?>");
			});
		</script>
		<?php
		setcookie('wishlist_error', '', time() - 3600, "/"); // Clear the cookie
	}
}
add_action('wp_footer', 'display_toastr_notification');

// function redirect_to_cart_after_order($order_id, $posted_data, $order)
// {
// 	if (!is_admin()) {
// 		wc_clear_cart(); // Clear the cart after order placement
// 		wp_safe_redirect(wc_get_cart_url()); // Redirect to the cart page
// 		exit;
// 	}
// }
// add_action('woocommerce_checkout_order_processed', 'redirect_to_cart_after_order', 10, 3);

// FAQ Custom Post Type
function create_posttype()
{
	register_post_type(
		'FAQ',
		array(
			'labels' => array(
				'name' => __('FAQ'),
				'singular_name' => __('FAQ')
			),
			'public' => true,
			'has_archive' => true,
			'rewrite' => array('slug' => 'faq'),
			'show_in_rest' => true,
			'taxonomies' => array('category'),
		)
	);
}
add_action('init', 'create_posttype');


function custom_password_reset_message($message, $key, $user_login, $user_data)
{
	return __('A password reset email has been sent to the registered email address. It may take few minutes to show up in your inbox.', 'text-domain');
}
add_filter('password_reset_messages', 'custom_password_reset_message', 10, 4);


function custom_reset_password_expiration($expiration)
{
	return 3600; // 3600 seconds = 1 hour
}
add_filter('password_reset_expiration', 'custom_reset_password_expiration');

add_action('woocommerce_admin_order_data_after_billing_address', function ($order) {
	$deliver_to_couple = $order->get_meta('_deliver_to_couple');
	if ($deliver_to_couple) {
		echo '<p><strong>Deliver to Couple:</strong> ' . esc_html($deliver_to_couple) . '</p>';
	}
});


add_action('woocommerce_thankyou', function ($order_id) {
	if (!$order_id)
		return;

	$order = wc_get_order($order_id);
	$deliver_to_couple = $order->get_meta('_deliver_to_couple');

	if ($deliver_to_couple) {
		echo '<p><strong>Deliver to Couple:</strong> ' . esc_html($deliver_to_couple) . '</p>';
	}
});


add_action('woocommerce_email_after_order_table', function ($order, $sent_to_admin, $plain_text, $email) {
	if ($sent_to_admin && $email->id === 'new_order') {
		$deliver_to_couple = $order->get_meta('_deliver_to_couple');
		if ($deliver_to_couple) {
			echo '<p><strong>Deliver to Couple:</strong> ' . esc_html($deliver_to_couple) . '</p>';
		}
	}
}, 20, 4);


add_action('template_redirect', function () {
	if (is_checkout() && !is_wc_endpoint_url('order-received')) {
		if (WC()->cart->is_empty()) {
			wp_redirect(wc_get_cart_url());
			exit;
		}
	}
});

add_filter('http_request_timeout', function () {
	return 60; // Increase to 60 seconds
});

add_filter('http_request_host_is_external', function ($allow, $host) {
	if (strpos($host, 'razorpay.com') !== false) {
		return true;
	}
	return $allow;
}, 10, 2);

add_action('woocommerce_thankyou', 'display_gift_message_on_thankyou', 20);
function display_gift_message_on_thankyou($order_id)
{
	$gift_message = get_post_meta($order_id, 'gift_message', true);
	if (!empty($gift_message)) {
		echo '<h2>' . __('Gift Message') . '</h2>';
		echo '<p>' . nl2br(esc_html($gift_message)) . '</p>';
	}
}

add_filter('woocommerce_order_item_get_formatted_meta_data', 'remove_vendor_name_from_order_meta', 10, 2);
function remove_vendor_name_from_order_meta($formatted_meta, $order_item)
{
	foreach ($formatted_meta as $key => $meta) {
		if (isset($meta->key) && $meta->key === 'Vendor') {
			unset($formatted_meta[$key]);
		}
	}
	return $formatted_meta;
}

add_filter('woocommerce_order_item_get_formatted_meta_data', 'replace_gift_for_id_with_name', 20, 2);
function replace_gift_for_id_with_name($formatted_meta, $order_item)
{
	foreach ($formatted_meta as $key => $meta) {
		if ($meta->key === 'gift_for') {
			$user_id = $meta->value;
			$first_name = get_user_meta($user_id, 'first_name', true);
			$last_name = get_user_meta($user_id, 'last_name', true);

			if ($first_name || $last_name) {
				$full_name = trim($first_name . ' ' . $last_name);
				$meta->value = $full_name;
			} else {
				$meta->value = __('User not found');
			}

			$formatted_meta[$key] = $meta;
		}
	}
	return $formatted_meta;
}

add_action('init', function () {
	remove_action('woocommerce_after_cart_item_name', 'dokan_product_seller_info', 10);
	remove_action('woocommerce_after_shop_loop_item_title', 'dokan_show_sold_by_on_the_shop_page', 9);
});



//add_action('woocommerce_order_item_meta_end', 'display_custom_order_item_meta_in_email', 10, 4);

// add_action('woocommerce_thankyou', 'custom_thank_you_message', 20);
// function custom_thank_you_message($order_id) {
//     if (!$order_id) return;

//     $order = wc_get_order($order_id);
//     echo 'Thank you for choosing Modern Lifafa — The couple will be notified of your gift along with your personal message, so they can feel the love right away. 💌 We’ve also sent a confirmation email with all the details to your inbox.';
// }

// Make "Ship to a different address?" checkbox UNCHECKED by default
add_filter('woocommerce_ship_to_different_address_checked', '__return_false');

// Copy billing address to shipping when checkbox is unchecked
add_action('woocommerce_checkout_process', 'auto_copy_billing_to_shipping');
function auto_copy_billing_to_shipping()
{
	if (empty($_POST['ship_to_different_address'])) {
		foreach ($_POST as $key => $value) {
			if (strpos($key, 'billing_') === 0) {
				$shipping_key = str_replace('billing_', 'shipping_', $key);
				$_POST[$shipping_key] = $value;
			}
		}
	}
}
function custom_woocommerce_order_received_subject($subject, $order)
{
	$subject = 'Thanks for your order!';
	return $subject;
}

add_filter('gettext', 'change_empty_cart_message', 20, 3);
function change_empty_cart_message($translated, $text, $domain)
{
	if (strpos($text, 'No products in the cart') !== false) {
		return 'Looks like your cart is empty, keep browsing for the perfect gift!';
	}
	return $translated;
}

// Custom password error message
function custom_password_error_message($user, $password)
{
	if (!wp_check_password($password, $user->user_pass, $user->ID)) {
		return new WP_Error(
			'incorrect_password',
			sprintf(
				__('Hmm, that password didn’t match. Try again or <a href="%s">reset your password here</a> if you need a little help!'),
				wp_lostpassword_url()
			)
		);
	}
	return $user;
}

add_filter('wp_authenticate_user', 'custom_password_error_message', 10, 2);

function custom_email_exists_error_message($message, $email)
{
	$login_url = home_url('/my-account/');
	return __('Looks like you already have an account with us—just ', 'woocommerce') .
		'<a href="' . esc_url($login_url) . '">log in</a>' .
		__(' to pick up where you left off!', 'woocommerce');
}

add_filter('woocommerce_registration_error_email_exists', 'custom_email_exists_error_message', 10, 2);


// Hook to handle the AJAX request
add_action('wp_ajax_update_personalized_product_quantity', 'update_personalized_product_quantity');
add_action('wp_ajax_nopriv_update_personalized_product_quantity', 'update_personalized_product_quantity');
function update_personalized_product_quantity()
{
	$user_id = get_current_user_id();
	if (!$user_id) {
		wp_send_json_error(['message' => 'User not logged in.']);
	}

	$product_id = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0;
	$variation_id = isset($_POST['variation_id']) ? absint($_POST['variation_id']) : 0;
	$qty = isset($_POST['qty']) ? intval($_POST['qty']) : 1;
	$raw_attributes = isset($_POST['attributes']) ? $_POST['attributes'] : '';
	if ($raw_attributes === '""' || $raw_attributes === '') {
    	$saved_attributes = null;
	} else {
		$decoded = json_decode(stripslashes($raw_attributes), true);
		if (is_array($decoded)) {
			$saved_attributes = wc_clean($decoded);
		} else {
			$saved_attributes = null;
		}
	}
	$personalized_products = get_user_meta($user_id, '_personalized_products', true);
	if (!is_array($personalized_products))
		$personalized_products = [];
	$product_qty = get_user_meta($user_id, '_product_quantity', true);
	if (!is_array($product_qty))
		$product_qty = [];
	$matched = false;
	$item_variation_id = '';
	// if($saved_attributes){
		foreach ($personalized_products as &$item) {
			$item_attrs = isset($item['attributes']) ? wc_clean((array) $item['attributes']) : [];
			ksort($item_attrs);

			$item_variation_id = isset($item['variation_id']) ? intval($item['variation_id']) : 0;

			$is_match = intval($item['product_id']) === $product_id;

			if ($saved_attributes !== null) {
				$is_match = $is_match && ($item_attrs === $saved_attributes);
			}

			if ($is_match) {
				$item['quantity'] = $qty;
				$key = $variation_id ? ($product_id . '_' . $variation_id) : $product_id;
				$product_qty[$key] = $qty;
				$matched = true;
				break;
			}
		}

	if (!$matched) {
		wp_send_json_error(['message' => 'Matching personalized product not found.']);
	}
	// }

	update_user_meta($user_id, '_personalized_products', $personalized_products);
	update_user_meta($user_id, '_product_quantity', $product_qty);

	wp_send_json_success(['message' => 'Product quantity updated.']);
}
// add_action('wp_ajax_update_personalized_product_quantity', 'update_personalized_product_quantity');


function cf7_success_popup_markup()
{
	if (is_page('contact-us')) { // Change to your actual page slug
		?>
		<div id="cf7-success-popup" style="display: none;">
			<div class="popup-overlay"
				style="position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(0, 0, 0, 0.5); z-index:9998;">
			</div>
			<div class="popup-content"
				style="position: fixed; top:50%; left:50%; transform: translate(-50%, -50%); background:#fff; padding: 20px 30px; border-radius: 8px; z-index:9999;">
				<div class="custom-notification">
					<div class="notification-content">
						<div class="message">
							<p></p>
							<div class="share-wishlist-address">
								<p>Thanks for dropping by! We’ve got your message and will be in touch soon.</p>
							</div>
							<p></p>
						</div>
						<button class="notification-btn" id="popup-close">Close</button>
					</div>
				</div>

			</div>
		</div>

		<script>
			document.addEventListener('DOMContentLoaded', function () {
				document.addEventListener('wpcf7mailsent', function () {
					const popup = document.getElementById('cf7-success-popup');
					if (popup) {
						popup.style.display = 'block';
					}
				});

				const closeBtn = document.getElementById('popup-close');
				if (closeBtn) {
					closeBtn.addEventListener('click', function () {
						const popup = document.getElementById('cf7-success-popup');
						if (popup) {
							popup.style.display = 'none';
						}
					});
				}
			});
		</script>
		<?php
	}
}
add_action('wp_footer', 'cf7_success_popup_markup');



function custom_indian_price_format($formatted_price, $price, $args)
{
	$formatted_number = indian_number_format($price);
	return $formatted_number;
}

function indian_number_format($number)
{
	$decimal = '';
	if (strpos($number, '.') !== false) {
		list($number, $decimal) = explode('.', $number);
		$decimal = '.' . substr($decimal, 0, 2); // limit to 2 decimal places
	}

	$length = strlen($number);
	if ($length > 3) {
		$last3 = substr($number, -3);
		$restUnits = substr($number, 0, $length - 3);
		$restUnits = preg_replace("/\B(?=(\d{2})+(?!\d))/", ",", $restUnits);
		return $restUnits . ',' . $last3 . $decimal;
	} else {
		return $number . $decimal;
	}
}

add_filter('formatted_woocommerce_price', 'custom_indian_price_format', 10, 3);

add_action('woocommerce_checkout_process', function () {
	if (!empty($_POST['gift_message']) && strlen($_POST['gift_message']) > 150) {
		wc_add_notice(__('Gift message must be 150 characters or less.', 'woocommerce'), 'error');
	}
	if (!empty($_POST['order_comments']) && strlen($_POST['order_comments']) > 150) {
		wc_add_notice(__('Order note must be 150 characters or less.', 'woocommerce'), 'error');
	}
});


function characters_limit()
{

	?>
	<div id="characters_limit" style="display: none;">
		<div class="popup-overlay"
			style="position: fixed; top:0; left:0; width:100%; height:100%; background: rgba(0, 0, 0, 0.5); z-index:9998;">
		</div>
		<div class="popup-content"
			style="position: fixed; top:50%; left:50%; transform: translate(-50%, -50%); background:#fff; padding: 20px 30px; border-radius: 8px; z-index:9999;">
			<div class="custom-notification">
				<div class="notification-content">
					<div class="message">
						<p></p>
						<div class="share-wishlist-address">
							<p></p>
						</div>
						<p></p>
					</div>
					<button class="notification-btn" id="popup-close">Close</button>
				</div>
			</div>

		</div>
	</div>

	<script>

		document.addEventListener("DOMContentLoaded", function () {
			const limitFields = ['gift_message', 'order_comments'];

			function showPopup(message) {
				const popup = document.getElementById('characters_limit');
				const messageEl = popup.querySelector('.message p'); // Target the <p> tag for message
				if (popup && messageEl) {
					messageEl.textContent = message;
					popup.style.display = 'block';
				}
			}


			limitFields.forEach(id => {
				const textarea = document.getElementById(id);
				if (textarea) {
					textarea.addEventListener('input', function () {
						if (this.value.length > 150) {
							this.value = this.value.substring(0, 150);
							showPopup("Oops! Please keep your message under 150 characters.");
						}
					});
				}
			});

			const form = document.getElementById('custom-checkout-form');
			if (form) {
				form.addEventListener('submit', function (e) {
					let isValid = true;

					limitFields.forEach(id => {
						const field = document.getElementById(id);
						if (field && field.value.length > 150) {
							showPopup(`The "${id.replace('_', ' ')}" field cannot exceed 150 characters.`);
							isValid = false;
						}
					});

					if (!isValid) {
						e.preventDefault();
					}
				});
			}

			const closeBtn = document.getElementById('popup-close');
			if (closeBtn) {
				closeBtn.addEventListener('click', function () {
					const popup = document.getElementById('characters_limit');
					if (popup) {
						popup.style.display = 'none';
					}
				});
			}
		});

	</script>
	<?php
}

add_action('wp_footer', 'characters_limit');


// Charecter limit in product name wordpress backend
function limit_product_title_length_admin()
{
	$screen = get_current_screen();
	if ($screen && $screen->post_type === 'product') {
		?>
		<script>
			document.addEventListener("DOMContentLoaded", function () {
				const titleField = document.getElementById('title');
				if (titleField) {
					titleField.addEventListener('input', function () {
						if (this.value.length > 150) {
							this.value = this.value.substring(0, 150);
							alert("Product name cannot exceed 150 characters.");
						}
					});
				}
			});
		</script>
		<?php
	}
}
add_action('admin_footer', 'limit_product_title_length_admin');

// Add shortcode in cf7 for current year in mail



// Shortcode to return current year
function cf7_current_year_shortcode()
{
	return date("Y");
}
add_shortcode('current_year', 'cf7_current_year_shortcode');

// Allow shortcodes to run in CF7 mail templates
add_filter('wpcf7_special_mail_tags', function ($output, $name) {
	if ($name === 'current_year') {
		return date('Y');
	}
	return $output;
}, 10, 2);

// 06-05-2025
add_action('woocommerce_before_calculate_totals', 'set_custom_price_for_cart_items', 20, 1);
function set_custom_price_for_cart_items($cart) {
    if (is_admin() && !defined('DOING_AJAX')) return;

    // Only run once
    if (did_action('woocommerce_before_calculate_totals') >= 2) return;

    foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
        if (isset($cart_item['custom_price'])) {
            $cart_item['data']->set_price(floatval($cart_item['custom_price']));
        }
    }
}


add_action('woocommerce_checkout_order_processed', 'defer_email_sending', 10, 1);
function defer_email_sending($order_id) {
    if (function_exists('as_schedule_single_action')) {
        as_schedule_single_action(time() + 10, 'send_order_emails_later', array($order_id));
    }
}

add_action('send_order_emails_later', 'send_emails_background');
function send_emails_background($order_id) {
    WC()->mailer()->emails['WC_Email_Customer_Processing_Order']->trigger($order_id);
}

// Disable built-in WooCommerce emails
add_filter('woocommerce_email_enabled_new_order', '__return_false');
add_filter('woocommerce_email_enabled_customer_processing_order', '__return_false');
add_filter('woocommerce_email_enabled_customer_invoice', '__return_false');
add_filter('woocommerce_email_enabled_customer_completed_order', '__return_false');


// Step 1: Defer emails to background
add_action('woocommerce_checkout_order_processed', 'defer_all_emails_in_background', 10, 1);
function defer_all_emails_in_background($order_id) {
    if (function_exists('as_schedule_single_action')) {
        as_schedule_single_action(time() + 5, 'handle_wc_email_queue', array('order_id' => $order_id));
    }
}

// Step 2: Background email sender
add_action('handle_wc_email_queue', 'send_all_emails_background');
function send_all_emails_background($args) {
    if (empty($args['order_id'])) return;
    
    $order_id = $args['order_id'];
    $mailer = WC()->mailer();

    // List of emails to trigger manually
    $emails = [
        'WC_Email_New_Order',
        'WC_Email_Customer_Processing_Order',
        'WC_Email_Customer_Invoice',
        'WC_Email_Customer_Completed_Order',
    ];

    foreach ($emails as $email_key) {
        if (!empty($mailer->emails[$email_key])) {
            $mailer->emails[$email_key]->trigger($order_id);
        }
    }
}
