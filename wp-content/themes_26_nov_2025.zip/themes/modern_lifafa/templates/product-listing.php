<?php /* Template Name: Product Listing */ ?>

<?php // get_header(); ?>

<section class="our-products-section">
    <div class="container">
        <div class="filter-wrap">
            <?php if (is_user_logged_in()) { ?>
                <div class="backto-wishlist-wrapper">
                    <a href="<?php echo get_permalink(get_page_by_path('wishlist')); ?>"
                        class="back_wishlist custom_button desktop">Back To Wishlist</a>
                    <a href="<?php echo get_permalink(get_page_by_path('wishlist')); ?>" class="back_wishlist mobile">
                        <!-- <img class="BackwhishIcon" src="<?php echo get_template_directory_uri(); ?>/assets/images/back-to-top-svg.webp" alt="back-to-top" width="24" height="24">  -->
                        Back To Wishlist
                    </a>
                    <div class="filter-box clear_filter_mobile">
                        <input type="button" class="custom_button secondary_button clear_filter" value="Clear Filters" />
                    </div>
                </div>
            <?php } ?>
            <div class="filter-inner">
                <?php $terms = get_terms(array(
                    'taxonomy' => 'product_cat',
                    'hide_empty' => false,
                    'order' => 'ASC',
                ));
                if (!empty($terms) && !is_wp_error($terms)) {
                    echo '<div class="filter-box">';
                    echo '<select class="custome-selectbox product-filter filter-category" title="Filter by Category">';
                    // Placeholder option (disabled & selected)
                    echo '<option value="" disabled selected>Filter by Category</option>';
                    // "All" option with value
                    $selected = (isset($_GET['category']) && $_GET['category'] == 'All') ? 'selected' : '';
                    echo '<option value="All" ' . $selected . '>All</option>';
                    // Category options
                    foreach ($terms as $term) {
                        $selected = (isset($_GET['category']) && $_GET['category'] === $term->slug) ? 'selected' : '';
                        echo '<option value="' . esc_attr($term->slug) . '" ' . $selected . '>' . esc_html($term->name) . '</option>';
                    }
                    echo '</select></div>';
                }
                ?>
                <?php if (have_rows('price')) {
                    $price_options = array();
                    echo '<div class="filter-box">';
                    echo '<select class="custome-selectbox product-filter filter-price" title="Filter by Price">';

                    // Placeholder option (disabled & selected)
                    echo '<option value="" disabled selected>Filter by Price</option>';

                    // "All" option with value
                    $selected = (isset($_GET['price']) && $_GET['price'] == 'All') ? 'selected' : '';
                    echo '<option value="All" ' . $selected . '>All</option>';

                    // Collecting price ranges
                    while (have_rows('price')):
                        the_row();
                        $min = get_sub_field('min_price');
                        $max = get_sub_field('max_price');
                        if ($max > $min) {
                            $price_options[] = array('min' => $min, 'max' => $max);
                        }
                    endwhile;

                    // Sorting price options by min value
                    usort($price_options, function ($a, $b) {
                        return $a['min'] - $b['min'];
                    });

                    // Rendering price options
                    foreach ($price_options as $option) {
                        $value = $option['min'] . '-' . $option['max'];
                        $selected = (isset($_GET['price']) && $_GET['price'] === $value) ? 'selected' : '';
                        echo '<option value="' . esc_attr($value) . '" ' . $selected . '>';
                        echo get_woocommerce_currency_symbol() . indian_number_format($option['min']) . ' - ' . get_woocommerce_currency_symbol() . indian_number_format($option['max']);
                        echo '</option>';
                    }
                    $value = $_GET['price'];
                    $selected = (isset($_GET['price']) && $_GET['price'] === '20000-') ? 'selected' : '';
                    echo '<option value="20000-" ' . $selected . '>' . get_woocommerce_currency_symbol() . '20000 +</option>';

                    echo '</select></div>';
                } ?>

                <?php $terms = get_terms(array(
                    'taxonomy' => 'brand',
                    'hide_empty' => false,
                    'order' => 'ASC',
                ));
                if (!empty($terms) && !is_wp_error($terms)) {
                    echo '<div class="filter-box">';
                    echo '<select class="custome-selectbox product-filter filter-brand" title="Filter by Brand">';

                    // Placeholder option (disabled & selected)
                    echo '<option value="" disabled selected>Filter by Brand</option>';

                    // "All" option with value
                    $selected = (isset($_GET['filter_brand']) && $_GET['filter_brand'] == 'All') ? 'selected' : '';
                    echo '<option value="All" ' . $selected . '>All</option>';

                    // Loop through brands
                    foreach ($terms as $term) {
                        $value = esc_attr($term->slug); // Use slug for better filtering
                        $selected = (isset($_GET['filter_brand']) && $_GET['filter_brand'] === $term->slug) ? 'selected' : '';
                        echo '<option value="' . $value . '" ' . $selected . '>' . esc_html($term->name) . '</option>';
                    }

                    echo '</select></div>';
                } ?>
                <div class="filter-box clear_filter_desktop">
                    <input type="button" class="custom_button secondary_button clear_filter" value="Clear" />
                </div>
            </div>
        </div>
    </div>
</section>

<section class="product-listing-section">
    <div class="container">
        <?php
        $category = (isset($_GET['category'])) ? sanitize_text_field($_GET['category']) : '';
        if (isset($category) && $category == 'All') {
            $category = '';
        }
        $price = (isset($_GET['price'])) ? sanitize_text_field($_GET['price']) : '';
        if (isset($price) && $price == 'All') {
            $price = '';
        }
        // $brand = (isset($_GET['brand'])) ? sanitize_text_field($_GET['brand']) : '';
        $brand = (isset($_GET['filter_brand'])) ? sanitize_text_field($_GET['filter_brand']) : '';
        if (isset($brand) && $brand == 'All') {
            $brand = '';
        }
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $current_user_id = get_current_user_id();
        // $args = array(
        //     'post_type' => 'product',
        //     'posts_per_page' => 2,
        //     'paged' => $paged,
        //     'post_status' => 'publish'
        // );
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 12,
            'paged' => $paged,
            'post_status' => 'publish',
            'meta_query' => array(
                'relation' => 'OR',
                array(
                    'key' => '_added_by_user_id',
                    'value' => $current_user_id,
                    'compare' => '=',
                ),
                array(
                    'key' => '_added_by_user_id',
                    'compare' => 'NOT EXISTS',
                ),
            ),
        );
        $tax_query = array();
        if (isset($category) && !empty($category)) {
            $args['tax_query'][] = array(
                'taxonomy' => 'product_cat',
                'field' => 'slug',
                'terms' => strtolower($category)
            );
        }
        if (isset($brand) && !empty($brand)) {
            $args['tax_query'][] = array(
                'taxonomy' => 'brand',
                'field' => 'slug',
                'terms' => strtolower($brand)
            );
        }
        if (isset($price) && !empty($price)) {
            $price_range = explode('-', $price);
            $min_price = intval($price_range[0]);
            $max_price = isset($price_range[1]) ? intval($price_range[1]) : null;
            $args['meta_query'] = array();
            if ($max_price) {
                $args['meta_query'][] = array(
                    'key' => '_price',
                    'value' => array($min_price, $max_price),
                    'compare' => 'BETWEEN',
                    'type' => 'NUMERIC'
                );
            } else {
                $args['meta_query'][] = array(
                    'key' => '_price',
                    'value' => $min_price,
                    'compare' => '>=',
                    'type' => 'NUMERIC'
                );
            }
        }
        
        $products = new WP_Query($args);
        if ($products->have_posts()) {
            echo '<div class="product-list">';
            while ($products->have_posts()) {
                $products->the_post();
                wc_get_template_part('content', 'product');
            }
            echo '</div>';
            $total_pages = $products->max_num_pages;
            $big = 999999999;
            $pagination_args = array(
                'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                'format' => '?paged=%#%',
                'current' => max(1, $paged),
                'total' => $total_pages,
                'prev_next' => false,
                'prev_text' => __('<span aria-hidden="true" class="fas fa-chevron-left"></span>'),
                'next_text' => __('<span aria-hidden="true" class="fas fa-chevron-right"></span>'),
                'type' => 'array',
                'end_size' => 1,
                'mid_size' => 1
            );
            $links = paginate_links($pagination_args);
            if ($links) {
                morden_lifafa_pagination($links, $total_pages, $paged);
            }
            wp_reset_postdata();
        } else {
            echo '<div class="no-data-found">';
            echo '<strong>Oops, no results.</strong>
                <p>It seems we don’t have anything matching those filters. Try tweaking them, and we’ll show you some great options!</p>';
            echo "</div>";
        } ?>
    </div>
</section>

<?php //get_footer(); ?>